// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/hooks/useForceUpdate' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/hooks/useForceUpdate.d.ts';
}
