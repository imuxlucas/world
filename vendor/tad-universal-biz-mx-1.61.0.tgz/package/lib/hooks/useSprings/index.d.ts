// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/hooks/useSprings' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/hooks/useSprings.d.ts';
}
