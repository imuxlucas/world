// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/hooks/useSpring' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/hooks/useSpring.d.ts';
}
