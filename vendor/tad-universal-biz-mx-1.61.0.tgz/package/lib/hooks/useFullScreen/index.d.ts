// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/hooks/useFullScreen' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/hooks/useFullScreen.d.ts';
}
