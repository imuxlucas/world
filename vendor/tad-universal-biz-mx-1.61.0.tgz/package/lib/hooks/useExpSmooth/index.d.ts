// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/hooks/useExpSmooth' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/hooks/useExpSmooth.d.ts';
}
