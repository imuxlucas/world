// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/hooks/useEventHelper' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/hooks/useEventHelper.d.ts';
}
