// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/MxIconUrl/ClipboardAvatar' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/MxIcon/iconsUrl/ClipboardAvatar.d.ts';
}
