// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/MxIconUrl/DatabaseSearch' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/MxIcon/iconsUrl/DatabaseSearch.d.ts';
}
