// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/MxIconUrl/DocAiStar' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/MxIcon/iconsUrl/DocAiStar.d.ts';
}
