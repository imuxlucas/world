import { default as React } from 'react';
import { MxMediaAudioControlsContextType } from '../common';
export interface ControllerProps {
    /**
     * 子组件
     */
    children?: React.ReactNode;
    /**
     * 控制器Ref
     */
    contextRef?: React.Ref<MxMediaAudioControlsContextType>;
}
export declare const Controller: ({ children, contextRef }: ControllerProps) => import("react/jsx-runtime").JSX.Element;
