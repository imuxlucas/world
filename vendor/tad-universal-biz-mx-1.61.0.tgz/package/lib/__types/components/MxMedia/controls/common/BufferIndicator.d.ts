import { MediaContextMap } from './index';
export type BufferIndicatorContentRenderer<T extends keyof MediaContextMap> = (data: {
    buffering: boolean;
    visible: boolean;
    status: MediaContextMap[T]['mediaContext']['status'];
}) => React.ReactNode;
export interface BufferIndicatorProps<T extends keyof MediaContextMap> extends Omit<React.HTMLAttributes<HTMLDivElement>, 'children'> {
    mediaType: T;
    mediaContext: MediaContextMap[T]['mediaContext'];
    controlsContext: MediaContextMap[T]['controlsContext'];
    /**
     * 指示器内容/渲染方法
     */
    children?: React.ReactNode | BufferIndicatorContentRenderer<T>;
    /**
     * 可见延迟，小于此值时，不显示指示器，避免频繁闪烁
     *
     * 单位：ms
     */
    visibleDelay?: number;
}
export declare const BufferIndicator: <T extends keyof MediaContextMap>({ mediaType, mediaContext, controlsContext, children, visibleDelay, ...restProps }: BufferIndicatorProps<T>) => import("react/jsx-runtime").JSX.Element;
