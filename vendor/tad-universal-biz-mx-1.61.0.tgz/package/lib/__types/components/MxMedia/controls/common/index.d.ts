import { useEventHelper } from '../../../hooks';
import { Context } from 'react';
import { MxMediaVideoContextType } from '../../base/MxMediaVideo';
import { MxMediaAudioContextType } from '../../base/MxMediaAudio';
interface MxMediaControlsContextTypeBase<Metadata, Events extends {
    [K in keyof Events]: {
        data: unknown;
    };
}> {
    metadata: Metadata | null;
    buffering: boolean;
    paused: boolean;
    userPaused: boolean;
    muted: boolean;
    pause: () => void;
    play: () => void;
    seek: (percentage: number) => void;
    seekEnd: () => void;
    mute: () => void;
    unmute: () => void;
    setVolume: (volume: number) => void;
    getVolumeInfo: () => {
        volume: number;
        muted: boolean;
    };
    getTimeInfo: () => {
        currentTime: number;
        duration: number;
    };
    eventHelper: ReturnType<typeof useEventHelper<Events>>;
}
export type MxMediaAudioControlsEvents = {
    playStateChange: {
        data: {
            paused: boolean;
        };
    };
    timeInfoUpdate: {
        data: {
            currentTime: number;
            duration: number;
        };
    };
    volumeInfoUpdate: {
        data: {
            volume: number;
            muted: boolean;
        };
    };
    sourceChange: {
        data: {
            source: string;
        };
    };
};
export interface MxMediaAudioControlsContextType extends MxMediaControlsContextTypeBase<{
    duration: number;
}, MxMediaAudioControlsEvents> {
}
export declare const MxMediaAudioControlsContext: Context<MxMediaAudioControlsContextType>;
export type MxMediaVideoControlsEvents = {
    playStateChange: {
        data: {
            paused: boolean;
        };
    };
    timeInfoUpdate: {
        data: {
            currentTime: number;
            duration: number;
        };
    };
    volumeInfoUpdate: {
        data: {
            volume: number;
            muted: boolean;
        };
    };
    sourceChange: {
        data: {
            source: string;
        };
    };
};
export interface MxMediaVideoControlsContextType extends MxMediaControlsContextTypeBase<{
    width: number;
    height: number;
    duration: number;
}, MxMediaVideoControlsEvents> {
    isFullScreen: boolean;
    mediaRef: React.RefObject<HTMLVideoElement | null>;
    containerRef: React.RefObject<HTMLDivElement | null>;
    enterFullScreen: (target?: HTMLElement) => Promise<void>;
    exitFullScreen: () => Promise<void>;
}
export declare const MxMediaVideoControlsContext: Context<MxMediaVideoControlsContextType>;
export type MediaContextMap = {
    video: {
        mediaContext: MxMediaVideoContextType;
        controlsContext: MxMediaVideoControlsContextType;
        events: MxMediaVideoControlsEvents;
    };
    audio: {
        mediaContext: MxMediaAudioContextType;
        controlsContext: MxMediaAudioControlsContextType;
        events: MxMediaAudioControlsEvents;
    };
};
export {};
