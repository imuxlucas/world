import { default as React } from 'react';
import { MxMediaVideoControlsContextType } from '../common';
export interface ControllerProps {
    /**
     * 子组件
     */
    children?: React.ReactNode;
    /**
     * 控制器Ref
     */
    contextRef?: React.Ref<MxMediaVideoControlsContextType>;
}
export declare const Controller: ({ children, contextRef }: ControllerProps) => import("react/jsx-runtime").JSX.Element;
