import { default as React } from 'react';
import { MxIconSingleProps, MxIconUrlOptions, MxIconUrlStyle } from './MxIcon.types';
type SVGRComponent = React.FunctionComponent<React.SVGProps<SVGSVGElement> & {
    title?: string;
    titleId?: string;
    desc?: string;
    descId?: string;
}>;
export declare const IconComponentWrapper: (name: string, kebabName: string, IconSvg: SVGRComponent) => {
    ({ size, color, style, strokeScale, ...rest }: MxIconSingleProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
/**
 * 样式对象序列化为 style 属性值：驼峰属性转短横线，CSS 自定义属性（`--*`）保持原样，空值忽略
 */
export declare const serializeIconUrlStyle: (style?: MxIconUrlStyle) => string;
export declare const iconUrlWrapper: (name: string, iconUrl: string) => (options?: MxIconUrlOptions) => string;
export declare function IconManifestComponent<T extends Record<string, ReturnType<typeof IconComponentWrapper>>>(icons: T): {
    ({ name, ...rest }: {
        name: keyof T;
    } & MxIconSingleProps): import("react/jsx-runtime").JSX.Element | null;
    displayName: string;
};
export {};
