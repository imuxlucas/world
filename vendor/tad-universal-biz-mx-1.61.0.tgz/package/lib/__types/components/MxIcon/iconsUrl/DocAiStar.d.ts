/**
 * mxIconUrlDocAiStar (图标url字符串)
 *
 * 单独导入的SVG图标
 *
 * 文档: https://tad-universal.woa.com/biz-mx/?path=/docs/组件-mxicon-图标--文档
 */
export declare const url: (options?: import('..').MxIconUrlOptions) => string;
