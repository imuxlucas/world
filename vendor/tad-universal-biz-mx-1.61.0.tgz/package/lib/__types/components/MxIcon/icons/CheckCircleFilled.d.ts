/**
 * MxIconCheckCircleFilled (图标)
 *
 * 单独导入的SVG图标
 *
 * 文档: https://tad-universal.woa.com/biz-mx/?path=/docs/组件-mxicon-图标--文档
 */
declare const _default: {
    ({ size, color, style, strokeScale, ...rest }: import('..').MxIconSingleProps): import("react/jsx-runtime").JSX.Element;
    displayName: string;
};
export default _default;
