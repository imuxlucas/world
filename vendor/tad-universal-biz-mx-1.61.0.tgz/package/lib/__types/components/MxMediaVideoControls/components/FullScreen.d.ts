import { default as React } from 'react';
import { MxMediaVideoControlsContextType } from '../../MxMedia/controls/common';
export type FullScreenContentRenderer = (data: {
    isFullScreen: MxMediaVideoControlsContextType['isFullScreen'];
    enterFullScreen: MxMediaVideoControlsContextType['enterFullScreen'];
    exitFullScreen: MxMediaVideoControlsContextType['exitFullScreen'];
    mediaRef: MxMediaVideoControlsContextType['mediaRef'];
    containerRef: MxMediaVideoControlsContextType['containerRef'];
}) => React.ReactNode;
export interface FullScreenProps extends Omit<React.HTMLAttributes<HTMLButtonElement>, 'children'> {
    /**
     * 全屏按钮内容 / 全屏按钮渲染方法
     */
    children?: React.ReactNode | FullScreenContentRenderer;
    /**
     * 全屏目标
     *
     * @default 'container'
     */
    fullScreenTarget?: 'media' | 'container';
}
export declare const FullScreen: ({ children, fullScreenTarget, ...restProps }: FullScreenProps) => import("react/jsx-runtime").JSX.Element;
