import { BufferIndicatorContentRenderer as BufferIndicatorContentRendererCommon, BufferIndicatorProps as BufferIndicatorPropsCommon } from '../../MxMedia/controls/common/BufferIndicator';
export type BufferIndicatorContentRenderer = BufferIndicatorContentRendererCommon<'video'>;
export interface BufferIndicatorProps extends Omit<BufferIndicatorPropsCommon<'video'>, 'mediaType' | 'mediaContext' | 'controlsContext'> {
}
export declare const BufferIndicator: ({ ...restProps }: BufferIndicatorProps) => import("react/jsx-runtime").JSX.Element;
