export interface AutoHideContainerProps extends React.HTMLAttributes<HTMLDivElement> {
    children?: React.ReactNode;
    /**
     * 是否在缓冲时显示
     */
    showOnBuffering?: boolean;
    /**
     * 是否在暂停时显示
     */
    showOnPaused?: boolean;
    /**
     * 是否自动隐藏
     */
    autoHide?: boolean | {
        delay: number;
    };
    /**
     * 默认是否显示（非受控模式）
     */
    defaultShow?: boolean;
    /**
     * 是否可见(受控模式)
     */
    show?: boolean;
    /**
     * 可见性变化回调
     */
    onShowChange?: (show: boolean) => void;
    /**
     * 隐藏时是否同时隐藏光标
     */
    hideCursor?: boolean;
}
export declare const AutoHideContainer: ({ className, children, showOnBuffering, showOnPaused, autoHide, defaultShow, show, hideCursor, onShowChange, ...restProps }: AutoHideContainerProps) => import("react/jsx-runtime").JSX.Element;
