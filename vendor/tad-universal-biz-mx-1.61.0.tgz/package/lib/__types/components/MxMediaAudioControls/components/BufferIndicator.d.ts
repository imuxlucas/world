import { BufferIndicatorContentRenderer as BufferIndicatorContentRendererCommon, BufferIndicatorProps as BufferIndicatorPropsCommon } from '../../MxMedia/controls/common/BufferIndicator';
export type BufferIndicatorContentRenderer = BufferIndicatorContentRendererCommon<'audio'>;
export interface BufferIndicatorProps extends Omit<BufferIndicatorPropsCommon<'audio'>, 'mediaType' | 'mediaContext' | 'controlsContext'> {
}
export declare const BufferIndicator: ({ ...restProps }: BufferIndicatorProps) => import("react/jsx-runtime").JSX.Element;
