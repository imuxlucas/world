/**
 * 开发环境断言工具。
 *
 * 用于组件内部的「调用方用法不一致」提示（如复合组件子节点上的模式标注与父级不符）：
 * 开发环境输出一条统一格式的错误并指明修法，生产环境完全静默，**不抛错**——
 * 一个标注写错不应该让整页白屏。
 */
/**
 * 开发环境输出一条组件错误。
 *
 * @param scope 组件标识，如 `RxSelect.Value`
 * @param message 问题描述
 * @param hint 修法提示（可选），单独一行展示
 */
export declare const devError: (scope: string, message: string, hint?: string) => void;
/**
 * 条件不成立时在开发环境报错（生产环境静默）。
 *
 * @param condition 期望为真的条件
 * @param scope 组件标识，如 `RxSelect.Value`
 * @param message 问题描述
 * @param hint 修法提示（可选）
 */
export declare const devAssert: (condition: unknown, scope: string, message: string, hint?: string) => void;
