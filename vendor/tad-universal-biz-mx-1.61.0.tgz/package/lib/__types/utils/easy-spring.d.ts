/**
 * EasySpring — 共享弹簧动画引擎
 *
 * 全局单例：所有 spring controller 注册进同一张表，由**一条共享 RAF**统一积分推进，
 * 适合大量并存、需各自独立回弹的动画元素（每个 controller 有独立的 goal / velocity /
 * config / 生命周期回调）。
 *
 * 本文件为底层引擎，业务侧请优先使用 hooks（`useSpring` / `useSprings`）。
 */
export interface SpringConfig {
    mass?: number;
    tension?: number;
    friction?: number;
    precision?: number;
    velocity?: number;
    clamp?: boolean;
}
export type SpringOption = {
    config?: SpringConfig;
    value?: number;
    onChange?: (spring: SpringController) => void;
    onStart?: (spring: SpringController) => void;
    onRest?: (spring: SpringController) => void;
};
export type SpringController = {
    readonly current: number;
    readonly goal: number;
    readonly config: SpringConfig;
    /** 是否处于暂停态 */
    readonly paused: boolean;
    start: (value: number, config?: SpringConfig) => void;
    set: (value: number) => void;
    /** 暂停动画：冻结当前值与速度（保留），并让出 RAF；再次 start/set 或 resume 可继续 */
    pause: () => void;
    /** 从暂停处以保留的速度继续动画（未暂停或已静止时为 no-op） */
    resume: () => void;
    remove: () => void;
};
type SpringInfo = {
    runtime: {
        goal: number;
        current: number;
        v: number;
        running: boolean;
        paused: boolean;
        startConfig?: Required<SpringConfig>;
    };
    config: Required<SpringConfig>;
};
export declare const EasySpring: {
    springs: Map<string, {
        option: SpringOption;
        info: SpringInfo;
        controller: SpringController;
    }>;
    info: {
        raf: null | number;
        lastT: number;
    };
    startAnimationFrame(): void;
    stopAnimationFrame(): void;
    checkIdle(): void;
    controller(option: SpringOption): SpringController;
};
export {};
