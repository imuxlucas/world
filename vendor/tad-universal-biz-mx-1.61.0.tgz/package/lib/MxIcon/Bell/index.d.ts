// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/MxIcon/Bell' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/MxIcon/icons/Bell.d.ts';
}
