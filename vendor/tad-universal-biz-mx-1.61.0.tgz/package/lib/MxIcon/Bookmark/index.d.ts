// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-mx/lib/MxIcon/Bookmark' {
  export * from '@tencent/tad-universal-biz-mx/lib/__types/components/MxIcon/icons/Bookmark.d.ts';
}
