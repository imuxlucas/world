# 🪄✨ 📦 tad-universal-biz-mx

## TAD (Tencent Ad. Design) 通用化业务组件库 - 妙系列业务组件

> part of **☯️ TAD Universal Components**

<span>
<a href="https://mirrors.tencent.com/#/private/npm/detail?repo_id=537&project_name=%40tencent%2Ftad-universal-biz-mx" style="margin-right: 5px">
<img alt="mirrors" src="http://mirrors.tencent.com/mirrors/api/npm/package/badge?package_name=@tencent/tad-universal-biz-mx&label=latest" />
</a>
<a href="https://git.woa.com/tad-ag/tad-universal-components/tree/main/packages/lib-base/biz-mx/" style="margin-right: 5px">
<img alt="repo" src="https://badgen.net/badge/icon/Repo?icon=git&label=Git" />
</a>
<a href="https://stream.woa.com/pipeline#tad-ag/tad-universal-components" style="margin-right: 5px">
<img alt="stream" src="https://stream.woa.com/pipeline/stream/api/external/stream/projects/985222/pipelines/badge?file_path=.ci%2Ftag-push_build-publish.yaml" />
</a>
<img src="https://badgen.net/badge/icon/TAD/pink?icon=kofi&label=Powered by"/>
</span>

该项目旨在聚合妙系列分散的业务组件，实现高效复用。

## 使用方式

### 安装

```bash
npm i -S @tencent/tad-universal-biz-mx

# 使用其他包管理器
# yarn add @tencent/tad-universal-biz-mx
# pnpm i -S @tencent/tad-universal-biz-mx
```

> 本包包含两套组件体系：
>
> - **Mx 系列**：自研组件（`MxButton`、`MxSpinner` 等）
> - **Rx 系列**：基于 [Radix UI](https://www.radix-ui.com/) 的快速实现（`RxDialog`、`RxSelect` 等），无需额外安装 Radix 依赖（已作为 dependencies 打包）

### 引入组件

```ts
// In your app:
import { <ComponentName> } from '@tencent/tad-universal-biz-mx';
```

其中，组件样式css将作为组件的副作用加载  
若打包工具支持 tree-shaking（如 rollup / webpack 5+ 等），不用担心会引入多余的组件代码

你也可以通过子路径方式，单独引入某个子组件的代码。仅针对子组件本身需要进一步 tree-shaking 的情况

```ts
import { <ComponentName> } from '@tencent/tad-universal-biz-mx/lib/<ComponentName>'
```

## 开发

使用 [pnpm](https://pnpm.io/) 作为包管理工具，以支持 workspace 能力和较快的包安装。

```bash
# 安装pnpm
npm install -g pnpm
```

整体采用 monorepo 方式管理，切换路径到 `packages/lib-base/biz-mx` 即可运行各个 npm script 来进行开发；或通过 pnpm `-F` 从项目根目录运行命令（见 [项目 Readme](../../README.md#开发)）。以前者为例：

```bash
cd './packages/lib-base/biz-mx'

# 启动开发环境（storybook）
pnpm run dev

# 新增一个组件 (交互式向导)
pnpm run new

# 更新组件索引文件（一般不用手动执行，仅在删除组件时需要手动执行）
pnpm run update:index

# 更新图标组件（本地开发时，图标有新增或删除需手动执行，构建或发布流水线也会自动执行）
pnpm run update:icons

# 构建组件
pnpm run build

# 构建storybook
pnpm run build:storybook
```

## CSS Layer 兼容性

本库所有组件样式包裹在 `@layer biz-mx` 中，这是标准 CSS Cascade Layers 语法，确保 Tailwind 等 utility-first 框架的 utility class 可以覆盖组件默认样式。

### 不使用 Tailwind 的项目

无需任何配置，`@layer biz-mx` 会被浏览器当作标准 CSS layer 处理。

### 使用 Tailwind v4 的项目

在入口 CSS 文件中声明 layer 顺序，将 `biz-mx` 放在 `utilities` 之前：

```css
/* 必须放在 @import 'tailwindcss' 之前 */
@layer theme, base, biz-mx, components, utilities;
@import 'tailwindcss';
```

> **注意顺序**：`@layer` 声明必须放在 `@import 'tailwindcss';` **之前**。
> CSS layer 的顺序由首次声明决定，Tailwind 内部已声明 `@layer theme, base, components, utilities;`，
> 若我们的声明在其后，浏览器会忽略；同时未排序的 `biz-mx` layer 会被排到最后（优先级最高），
> 导致 Tailwind utility 无法覆盖组件样式。

### 使用 Tailwind v3 的项目

Tailwind v3 的 PostCSS 插件会将 `@layer` 指令视为自有语法，需要在入口 CSS 中声明 `biz-mx` layer 并包裹 Tailwind 指令：

```css
@layer tailwind-base, biz-mx;

@layer tailwind-base {
  @tailwind base;
}

@tailwind components;
@tailwind utilities;
```

## 更多信息

见 [项目 Readme](../../README.md)
