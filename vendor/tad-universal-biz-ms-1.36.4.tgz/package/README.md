# ✨🤔 📦 tad-universal-biz-ms

## TAD (Tencent Ad. Design) 通用化业务组件库 - 妙思平台业务组件

> part of **☯️ TAD Universal Components**

<span>
<a href="https://mirrors.tencent.com/#/private/npm/detail?repo_id=537&project_name=%40tencent%2Ftad-universal-biz-ms" style="margin-right: 5px">
<img alt="mirrors" src="http://mirrors.tencent.com/mirrors/api/npm/package/badge?package_name=@tencent/tad-universal-biz-ms&label=latest" />
</a>
<a href="https://git.woa.com/tad-ag/tad-universal-components/tree/main/packages/lib-base/biz-ms/" style="margin-right: 5px">
<img alt="repo" src="https://badgen.net/badge/icon/Repo?icon=git&label=Git" />
</a>
<a href="https://stream.woa.com/pipeline#tad-ag/tad-universal-components" style="margin-right: 5px">
<img alt="stream" src="https://stream.woa.com/pipeline/stream/api/external/stream/projects/985222/pipelines/badge?file_path=.ci%2Ftag-push_build-publish.yaml" />
</a>
<img src="https://badgen.net/badge/icon/TAD/pink?icon=kofi&label=Powered by"/>
</span>

## 使用方式

### 安装

```bash
npm i -S tdesign-react @tencent/tad-universal-biz-ms

# 使用其他包管理器
# yarn add tdesign-react @tencent/tad-universal-biz-ms
# pnpm i -S tdesign-react @tencent/tad-universal-biz-ms
```

### 引入组件

```ts
// In your app:
import { <ComponentName> } from '@tencent/tad-universal-biz-ms';
```

其中，组件样式css将作为组件的副作用加载  
若打包工具支持 tree-shaking（如 rollup / webpack 5+ 等），不用担心会引入多余的组件代码

你也可以通过子路径方式，单独引入某个子组件的代码。仅针对子组件本身需要进一步 tree-shaking 的情况

```ts
import { <ComponentName> } from '@tencent/tad-universal-biz-ms/lib/<ComponentName>'
```

## 开发

使用 [pnpm](https://pnpm.io/) 作为包管理工具，以支持 workspace 能力和较快的包安装

```bash
# 安装pnpm
npm install -g pnpm
```

整体采用 monorepo 方式管理，切换路径到 `packages/lib-base/biz-ms` 即可运行各个 npm script 来进行开发；或通过 pnpm `--filter` 从项目根目录运行命令（见 [项目 Readme](../../README.md#开发)）。以前者为例：

```bash
cd './packages/lib-base/biz-ms'

# 启动开发环境（storybook）
pnpm run dev

# 新增一个组件 (交互式向导)
pnpm run new

# 更新组件索引文件（一般不用手动执行，仅在删除组件时需要手动执行）
pnpm run update:index

# 构建组件
pnpm run build

# 构建storybook
pnpm run build:storybook
```

## 更多信息

见 [项目 Readme](../../README.md)
