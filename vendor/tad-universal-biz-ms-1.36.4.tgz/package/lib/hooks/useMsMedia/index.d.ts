// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-ms/lib/hooks/useMsMedia' {
  export * from '@tencent/tad-universal-biz-ms/lib/__types/components/hooks/useMsMedia.d.ts';
}
