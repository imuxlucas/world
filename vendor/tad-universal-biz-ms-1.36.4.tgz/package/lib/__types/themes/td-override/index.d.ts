import { JSX } from 'react';
import { GlobalConfigProvider } from 'tdesign-react';
export declare const TIconWrapper: (Icon: any, propsOverride?: {
    className?: string;
}) => () => JSX.Element;
export declare const globalConfig: GlobalConfigProvider;
