import { default as React } from 'react';
import { ImageGridItem } from './MsSubjectDropPanel.types';
export interface ImageGridPreviewProps {
    /** 多张图片（≤1 张返回 null，不渲染拼图） */
    images: ImageGridItem[];
}
/**
 * 多图 hover 气泡内的 grid 拼图（整体始终 1:1，固定 168×168）。
 * 输入框主体标签 / 任务列表主体标签共用此组件，保证「组图」展示完全一致。
 * - ≥4 张：四宫格（取前 4）；
 * - 2-3 张：主图 + 小图布局。
 */
export declare const ImageGridPreview: React.FC<ImageGridPreviewProps>;
