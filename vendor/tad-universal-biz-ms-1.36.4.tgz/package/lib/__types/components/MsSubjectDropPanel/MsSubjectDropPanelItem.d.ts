import { default as React } from 'react';
import { MsSubjectDropPanelItemProps } from './MsSubjectDropPanel.types';
/**
 * `MsSubjectDropPanel.Item` — 妙思主体卡片
 *
 * 「已上传素材」与「主体库」共用同一 Item：
 * - 左侧缩略图（`MxMedia` 渲染），`enableThumbnailPreview` 开启后 hover 会通过
 *   `RxPopover` 在缩略图左侧弹出放大预览气泡（`previewAspectRatio` 决定气泡比例）
 * - 中间主体名称（单行省略）
 * - 右侧 `actionSlot`（hover 时才显示，如主体库的三点菜单按钮）
 *
 * 组件可单独使用，也可由父组件 `MsSubjectDropPanel` 根据 `uploadedItems` / `libraryItems` 自动渲染。
 */
export declare const MsSubjectDropPanelItem: React.ForwardRefExoticComponent<MsSubjectDropPanelItemProps & React.RefAttributes<HTMLDivElement>>;
