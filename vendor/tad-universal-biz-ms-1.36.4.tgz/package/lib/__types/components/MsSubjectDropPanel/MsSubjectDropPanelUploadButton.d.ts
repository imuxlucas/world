import { default as React } from 'react';
import { MsSubjectDropPanelUploadAction } from './MsSubjectDropPanel.types';
export interface MsSubjectDropPanelUploadButtonProps {
    className?: string;
    /** 主按钮文案 */
    label: React.ReactNode;
    /**
     * hover 时右侧弹出的子按钮列表
     *
     * 非空数组：主按钮不响应点击，hover 时由 `RxPopover` 在右侧弹出子按钮气泡；
     * 空 / 未传：主按钮直接响应 `onClick`。
     */
    actions?: MsSubjectDropPanelUploadAction[];
    /** 主按钮点击回调（仅在无 actions 时生效） */
    onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}
/**
 * 上传按钮 —— 「创建主体」
 *
 * 复用 `MxButton`（`variant="ghost"`）承载。hover 主按钮时，通过 `RxPopover`（hover 触发，
 * `side="right"`）在右侧弹出气泡，展示业务方注入的 `actions` 子按钮（如「从本地添加」/「从资产添加」）。
 */
export declare const MsSubjectDropPanelUploadButton: React.FC<MsSubjectDropPanelUploadButtonProps>;
