import { default as React } from 'react';
/**
 * hover 放大预览「组图」中的单张图片
 *
 * 用于 `MsSubjectItemData.previewImages` / `MsSubjectDropPanelItemProps.previewImages`，
 * 传入多张时，放大气泡内渲染为拼图（参考 `ImageGridPreview`）。
 */
export interface ImageGridItem {
    /** 图片 URL */
    url: string;
    /** 图片名称（可选，用于占位 / 无障碍 `alt`） */
    name?: string;
}
/**
 * 缩略图 hover 放大预览气泡支持的 5 种标准宽高比（对应 5 种固定像素尺寸）
 *
 * 组件内部会按比例渲染 `MxMedia`，避免拉伸。放大预览仅支持这 5 种尺寸。
 */
export type MsSubjectPreviewAspectRatio = '1/1' | '9/16' | '16/9' | '3/4' | '4/3';
/**
 * 预览比例入参
 *
 * 接受任意 `w/h` 字符串（如 `'2/3'`、`'5/4'`，便于直接透传后端返回的真实图片比例）；
 * 非标准比例会在组件内部按 w/h 数值**就近规整**到 {@link MsSubjectPreviewAspectRatio} 之一，
 * 以命中 5 种固定像素尺寸之一。`(string & {})` 仅用于在保留 5 个字面量自动补全的同时放行任意字符串。
 */
export type MsSubjectPreviewAspectRatioInput = MsSubjectPreviewAspectRatio | (string & {});
/**
 * 妙思主体条目数据
 *
 * 「已上传素材」与「主体库」共用同一种数据结构；
 * 通过 `MsSubjectDropPanelProps.uploadedItems` / `libraryItems` 分别注入。
 */
export interface MsSubjectItemData {
    /**
     * 唯一标识
     */
    key: string;
    /**
     * 主体名称
     */
    name: React.ReactNode;
    /**
     * 主体缩略图 URL
     *
     * 传入图片 URL，组件内部通过 `MxMedia` 渲染；不传时展示占位背景。
     */
    thumbnail?: string;
    /**
     * hover 放大预览时使用的大图 URL
     *
     * 不传则回退到 `thumbnail`。放大气泡由 `RxPopover`（hover 触发，展示在缩略图左侧）承载。
     */
    previewImage?: string;
    /**
     * hover 放大预览的「组图」图片数组
     *
     * 传入 **≥2 张** 时，放大气泡（`RxPopover` 承载，展示在缩略图左侧）内渲染为拼图（参考 `ImageGridPreview`）；
     * 仅 1 张或为空时，回落到 `previewImage` / `thumbnail` 的单图预览。
     *
     * 缩略图位置始终只展示 `thumbnail`（或 `previewImage`）单张，不受本字段影响；
     * 即「卡片缩略图显示单张、多图时放大预览显示拼图」的展示规则。
     */
    previewImages?: ImageGridItem[];
    /**
     * 缩略图 hover 放大预览气泡的宽高比
     *
     * 推荐使用 `1/1` / `9/16` / `16/9` / `3/4` / `4/3` 五种标准比例；
     * 传入其他 `w/h` 时会就近规整到最相近的标准比例。不传默认 `1/1`。
     *
     * @default '1/1'
     */
    previewAspectRatio?: MsSubjectPreviewAspectRatioInput;
    /**
     * 是否禁用（禁用后不响应点击与 hover 动作，也不展示三点菜单入口）
     */
    disabled?: boolean;
    /**
     * 条目级三点菜单操作项
     *
     * 传入非空数组时，该条目 hover 后右侧出现三点按钮，点击展开下拉菜单；
     * 不传（或为空数组）时该条目不显示三点入口——
     * 借此可实现「有的条目有操作、有的没有」以及不同条目展示不同操作项。
     *
     * 优先级高于面板级 `libraryItemMenuActions`（传 `[]` 可显式关闭该条目的菜单）。
     * 「已上传素材」与「主体库」分区均生效。
     */
    menuActions?: MsSubjectLibraryItemMenuAction[];
}
/**
 * 上传按钮 hover 时右侧展开的子按钮配置
 *
 * 用于「从本地添加」/「从资产添加」等入口。
 */
export interface MsSubjectDropPanelUploadAction {
    /**
     * 唯一标识
     */
    key: string;
    /**
     * 子按钮文案
     */
    label: React.ReactNode;
    /**
     * 子按钮图标（可选）
     */
    icon?: React.ReactNode;
    /**
     * 子按钮点击回调
     */
    onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}
/**
 * 主体库卡片 hover 三点菜单项
 *
 * 每个卡片右侧的三点按钮点击后展开的下拉菜单项。
 * 默认设计包含「编辑主体」/「删除」两项，可完全自定义。
 */
export interface MsSubjectLibraryItemMenuAction {
    /**
     * 唯一标识
     */
    key: string;
    /**
     * 菜单项文案
     */
    label: React.ReactNode;
    /**
     * 菜单项图标（可选）
     */
    icon?: React.ReactNode;
    /**
     * 是否为危险操作（视觉上以红色强调，如「删除」）
     */
    danger?: boolean;
    /**
     * 是否禁用
     */
    disabled?: boolean;
    /**
     * 点击回调
     *
     * @param item 当前所属的主体数据
     */
    onClick?: (item: MsSubjectItemData, e: React.MouseEvent<HTMLDivElement>) => void;
}
/**
 * `MsSubjectDropPanel.Item` 子组件配置
 *
 * 面板内的单张主体卡片。可由父组件根据 `uploadedItems` / `libraryItems` 自动渲染，
 * 也可通过 `MsSubjectDropPanel.Item` 直接组合使用。
 *
 * 左侧缩略图默认支持 hover 放大预览（`enableThumbnailPreview`），
 * 右侧支持通过 `actionSlot` 注入 hover 时才显示的按钮（如三点菜单）。
 */
export interface MsSubjectDropPanelItemProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'title' | 'onClick'> {
    /**
     * 主体缩略图 URL
     */
    thumbnail?: string;
    /**
     * hover 放大预览时使用的大图 URL；不传时回退到 `thumbnail`
     */
    previewImage?: string;
    /**
     * hover 放大预览的「组图」图片数组
     *
     * 传入 **≥2 张** 时，放大气泡内渲染为拼图（参考 `ImageGridPreview`）；
     * 仅 1 张或为空时回落到 `previewImage` / `thumbnail` 的单图预览。
     * 缩略图位置始终只展示 `thumbnail`（或 `previewImage`）单张。
     */
    previewImages?: ImageGridItem[];
    /**
     * 缩略图 hover 放大预览气泡的宽高比
     *
     * 推荐使用 `1/1` / `9/16` / `16/9` / `3/4` / `4/3` 五种标准比例；
     * 传入其他 `w/h` 时会就近规整到最相近的标准比例。不传默认 `1/1`。
     *
     * @default '1/1'
     */
    previewAspectRatio?: MsSubjectPreviewAspectRatioInput;
    /**
     * 主体名称
     */
    name: React.ReactNode;
    /**
     * 是否禁用
     */
    disabled?: boolean;
    /**
     * 是否选中（视觉强调态）
     */
    selected?: boolean;
    /**
     * 是否启用左侧缩略图 hover 放大预览（`RxPopover` 承载，展示在缩略图左侧）
     *
     * @default true
     */
    enableThumbnailPreview?: boolean;
    /**
     * 右侧动作区插槽
     *
     * hover 卡片时才显示；点击已阻止冒泡，不会触发卡片自身的 `onClick`。
     * 常见用途：注入主体库卡片的三点菜单按钮。
     */
    actionSlot?: React.ReactNode;
    /**
     * 卡片点击回调
     */
    onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
}
/**
 * 组件 MsSubjectDropPanel (妙思选择主体下拉面板) 的配置项
 *
 * 组件本体仅是「面板内容」，唤起方式（按钮点击 / 输入框聚焦 / 快捷键等）
 * 由外层使用 `RxPopover` / `RxDialog` / 自定义容器组合。
 *
 * 面板结构：
 * 1. 顶部「创建主体」上传按钮（hover 时右侧弹出 `RxPopover`，展示「从本地添加」/「从资产添加」等入口）
 * 2. 「已上传素材」分区（可选）
 * 3. 「主体库」分区（可选，`libraryItems.length > libraryMaxVisible` 时底部展示「更多主体」入口）
 *
 * 面板整体高度上限 400px，超出后整体滚动（不再对某个分区单独滚动）；
 * 顶部「创建主体」按钮在滚动时固定在面板顶部，不随内容滚动。
 */
export interface MsSubjectDropPanelProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onSelect'> {
    /**
     * 上传按钮文案
     *
     * @default '创建主体'
     */
    uploadButtonLabel?: React.ReactNode;
    /**
     * 上传按钮 hover 时右侧弹出的子按钮列表
     *
     * 传入非空数组时，鼠标 hover 主按钮会通过 `RxPopover`（hover 触发、`side="right"`）
     * 在右侧弹出子按钮气泡；此时点击主按钮不再触发 `onUploadButtonClick`。
     * 不传或为空数组时，主按钮直接响应 `onUploadButtonClick`。
     */
    uploadActions?: MsSubjectDropPanelUploadAction[];
    /**
     * 上传按钮点击回调
     *
     * 仅当 `uploadActions` 未提供时生效。
     */
    onUploadButtonClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
    /**
     * 是否展示「已上传素材」分区
     *
     * @default true
     */
    showUploadedSection?: boolean;
    /**
     * 「已上传素材」分区标题
     *
     * @default '已上传素材'
     */
    uploadedSectionTitle?: React.ReactNode;
    /**
     * 「已上传素材」数据
     *
     * 为空 / 未传时，整个分区（含标题）自动隐藏。
     */
    uploadedItems?: MsSubjectItemData[];
    /**
     * 是否展示「主体库」分区
     *
     * @default true
     */
    showLibrarySection?: boolean;
    /**
     * 「主体库」分区标题
     *
     * @default '主体库'
     */
    librarySectionTitle?: React.ReactNode;
    /**
     * 「主体库」数据
     *
     * 为空 / 未传时，整个分区（含标题）自动隐藏。
     */
    libraryItems?: MsSubjectItemData[];
    /**
     * 「主体库」列表最多显示条目数
     *
     * 超出后仅渲染前 `libraryMaxVisible` 项，并在面板底部展示「更多主体」入口，
     * 由业务方通过 `onMoreClick` 打开全量弹窗 / 抽屉查看剩余数据。
     *
     * @default 20
     */
    libraryMaxVisible?: number;
    /**
     * 主体库卡片 hover 三点菜单项
     *
     * 传入非空数组时，每张主体库卡片 hover 后右侧出现三点按钮，点击展开下拉菜单；
     * 不传或为空数组时，主体库卡片不显示三点入口。
     *
     * 如需按条目定制（有的条目有操作、有的没有），请使用数据上的
     * `MsSubjectItemData.menuActions`，其优先级高于本属性。
     *
     * 设计稿默认为「编辑主体」/「删除」两项。
     */
    libraryItemMenuActions?: MsSubjectLibraryItemMenuAction[];
    /**
     * 「更多主体」按钮文案
     *
     * 仅当 `libraryItems.length > libraryMaxVisible` 时自动展示。
     *
     * @default '更多主体'
     */
    moreButtonLabel?: React.ReactNode;
    /**
     * 「更多主体」按钮点击回调
     */
    onMoreClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
    /**
     * 当前选中的主体 key（视觉强调态）
     *
     * 「已上传素材」与「主体库」的卡片同用一套选中态。
     */
    activeItemKey?: string;
    /**
     * 主体卡片点击回调
     *
     * @param item   当前点击的主体数据
     * @param source 卡片所在分区：`uploaded` = 已上传素材、`library` = 主体库
     */
    onItemClick?: (item: MsSubjectItemData, source: 'uploaded' | 'library') => void;
    /**
     * 是否启用左侧缩略图 hover 放大预览
     *
     * @default true
     */
    enableThumbnailPreview?: boolean;
}
