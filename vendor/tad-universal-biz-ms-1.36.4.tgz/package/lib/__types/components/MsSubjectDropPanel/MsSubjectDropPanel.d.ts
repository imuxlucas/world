import { default as React } from 'react';
import { MsSubjectDropPanelProps } from './MsSubjectDropPanel.types';
import { MsSubjectDropPanelItem } from './MsSubjectDropPanelItem';
/**
 * MsSubjectDropPanel (妙思选择主体下拉面板)
 *
 * 组件本体仅为「面板内容」——不含 Trigger。
 * 唤起方式（按钮点击 / 输入框聚焦 / 快捷键等）由外层按需组合 `RxPopover` / `RxDialog` / 自定义容器。
 *
 * 面板结构：
 * 1. 顶部「创建主体」上传按钮（hover 时通过 `RxPopover` 在右侧弹出子按钮气泡）
 * 2. 「已上传素材」分区
 * 3. 「主体库」分区（超过 `libraryMaxVisible` 只渲染前 N 项，末尾展示「更多主体」入口）
 *
 * 面板整体最大高度 400px，超出后**整体**滚动（而非分区单独滚动）；
 * 顶部「创建主体」按钮在滚动时通过 `position: sticky` 固定在面板顶部不随内容滚动。
 *
 * 文档: https://tad-universal.woa.com/biz-ms/?path=/docs/组件-MsSubjectDropPanel-妙思选择主体下拉面板--文档
 */
declare const MsSubjectDropPanelBase: React.ForwardRefExoticComponent<MsSubjectDropPanelProps & React.RefAttributes<HTMLDivElement>>;
type MsSubjectDropPanelComponent = typeof MsSubjectDropPanelBase & {
    Item: typeof MsSubjectDropPanelItem;
};
export declare const MsSubjectDropPanel: MsSubjectDropPanelComponent;
export {};
