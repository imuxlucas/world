import { default as React } from 'react';
import { MsAiQuotaTagProps } from './MsAiQuotaTag.types';
/**
 * MsAiQuotaTag (妙思 AI 额度标签)
 *
 * 纯展示标签：渐变暖色边框 + 渐变 AI star 图标 + 数值。
 *
 * 使用方式：
 * ```tsx
 * <MsAiQuotaTag>5</MsAiQuotaTag>
 * <MsAiQuotaTag icon={<CustomIcon />}>剩余 12</MsAiQuotaTag>
 * <MsAiQuotaTag icon={null}>99+</MsAiQuotaTag>
 * ```
 */
export declare const MsAiQuotaTag: React.FC<MsAiQuotaTagProps>;
