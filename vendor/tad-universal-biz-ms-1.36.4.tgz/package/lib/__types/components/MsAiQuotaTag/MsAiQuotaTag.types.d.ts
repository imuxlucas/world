import { default as React } from 'react';
/**
 * MsAiQuotaTag 组件配置项
 *
 * 妙思 AI 额度标签：渐变暖色边框 + 渐变 AI star 图标 + 数值，纯展示用。
 */
export interface MsAiQuotaTagProps {
    /**
     * 标签类名
     */
    className?: string;
    /**
     * 标签样式
     */
    style?: React.CSSProperties;
    /**
     * 左侧图标（ReactNode）。
     *
     * 不传则使用默认渐变 AI star；传 `null` 可隐藏图标；传自定义节点可覆盖。
     */
    icon?: React.ReactNode;
    /**
     * 展示的数值/内容（ReactNode）
     */
    children?: React.ReactNode;
    /**
     * 是否可交互模式
     *
     * 为 true 时，hover 显示 pointer 光标，背景色变为 6% 透明度的渐变主色。
     * @default true
     */
    interactive?: boolean;
}
