import { default as React } from 'react';
import { MxButtonProps } from '@tencent/tad-universal-biz-mx';
/**
 * 模型额度条目（卡片上半部分 icon + label + value 行）
 */
export interface MsFeePlanCardModelFeature {
    /** 左侧图标（MxIcon 组件） */
    icon: React.ReactNode;
    /** 标签文案（支持 ReactNode，可在中间嵌入加粗子串） */
    label: React.ReactNode;
    /** 右侧数值（支持 ReactNode） */
    value: React.ReactNode;
    /**
     * 数值是否使用「妙思冷渐变」文字色（#ed4c4e → #c413ff）
     * - 用于 Pro 模型额度高亮
     */
    valueGradient?: boolean;
    /**
     * 数值下方的小字解释（如「约生成 1120 张图片或 280s 视频」）
     * - 缩进与 icon + gap 对齐
     */
    subNote?: string;
}
/**
 * 功能权益条目（卡片下半部分 check + label 行）
 */
export interface MsFeePlanCardFeatureItem {
    /** 权益文案（支持 ReactNode，可在中间嵌入加粗子串） */
    label: React.ReactNode;
    /**
     * 行尾徽标（如「付费专属」），渲染在 label 右侧
     * - 内置中性灰底小标签样式，传字符串即可
     * - 也可传自定义 ReactNode
     */
    tag?: React.ReactNode;
    /**
     * 是否隐藏该行（仍占据位置，用于多卡片对齐占位）
     * @default false
     */
    hidden?: boolean;
}
/**
 * MsFeePlanCard 组件配置项
 *
 * 妙思费用计划信息卡片（4 个配置：基础版 / 极速版 / Pro 标准版 / Pro 高级版）。
 * 配置式 API，不拆分子组件。横向拼接时可通过 `headerMinHeight` / `featuresMinHeight`
 * 控制各区域最小高度，使分割线上下两部分在视觉上对齐。
 */
export interface MsFeePlanCardProps {
    /**
     * 卡片标题（如「基础版」「Pro 标准版」）
     * - 支持 ReactNode，可在标题右侧嵌入徽标（如折扣标签 MsEmphasisTag）
     */
    title: React.ReactNode;
    /**
     * 副标题文案（与 `price` 二选一）
     * - 用于「基础版」等免费档位（如「广告主免费使用」）
     * - 不可与 price 同用
     */
    subtitle?: string;
    /**
     * 价格（如 19 / 159 / 899）
     * - 传 `subtitle` 时忽略
     */
    price?: number;
    /**
     * 划线原价（与 `price` 配套使用，显示在价格单位右侧）
     * - 用于「Pro 标准版」「Pro 高级版」等优惠档位
     */
    originalPrice?: number;
    /**
     * 价格单位（如「元/月」）
     * @default '元/月'
     */
    priceUnit?: string;
    /** 按钮文案（如「当前等级」「立即升级」） */
    buttonText: string;
    /**
     * 按钮变体
     * - `filled`：黑底白字（如「立即升级」）
     * - `outline`：白底带边框（如「当前等级」）
     * - `emphasis`：浅粉渐变背景 + 冷渐变文字，无 hover/active 交互态
     * @default 'filled'
     */
    buttonVariant?: 'filled' | 'outline' | 'emphasis';
    /** 按钮点击回调 */
    onButtonClick?: () => void;
    /**
     * 透传给操作按钮的额外 props（用于埋点等场景）。
     *
     * 典型用法是挂载 `data-*` 埋点属性，或补充 `id` / `aria-*` / 其它事件。
     * `onClick` 会与 `onButtonClick` 合并触发：先执行此处的 `onClick`，
     * 若未调用 `event.preventDefault()`，再执行 `onButtonClick`。
     *
     * `variant` / `size` / `intent` / `children` 由组件内部控制，故不可覆盖。
     * 对 `emphasis` 变体（原生 button），仅原生属性生效。
     *
     * @example
     * <MsFeePlanCard
     *   buttonText="立即升级"
     *   buttonProps={{ 'data-report-id': 'fee_plan_upgrade' }}
     * />
     */
    buttonProps?: Omit<MxButtonProps, 'variant' | 'size' | 'intent' | 'children'>;
    /** 模型额度条目（位于按钮下方） */
    modelFeatures?: MsFeePlanCardModelFeature[];
    /** 功能权益条目（位于分割线下方） */
    features?: MsFeePlanCardFeatureItem[];
    /**
     * 是否为推荐方案
     * - true 时整张卡片包裹在渐变容器中，并在卡片下方显示「推荐方案」徽标
     */
    recommended?: boolean;
    /**
     * 推荐方案徽标文案
     * @default '推荐方案'
     */
    recommendedBadge?: string;
    /**
     * 分割线以上区域（标题 + 价格 + 按钮 + 模型额度）的最小高度
     * - 横向拼接时使用，强制较小卡片与较大卡片上半身对齐
     */
    headerMinHeight?: number;
    /**
     * 分割线以下区域（功能权益）的最小高度
     * - 横向拼接时使用，强制较小卡片与较大卡片下半身对齐
     */
    featuresMinHeight?: number;
    /** 自定义类名（作用在最外层容器） */
    className?: string;
    /** 自定义样式（作用在最外层容器） */
    style?: React.CSSProperties;
}
