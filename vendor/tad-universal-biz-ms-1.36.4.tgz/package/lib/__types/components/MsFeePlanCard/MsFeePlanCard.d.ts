import { default as React } from 'react';
import { MsFeePlanCardProps } from './MsFeePlanCard.types';
/**
 * MsFeePlanCard（妙思费用计划信息卡片）
 *
 * 配置式 API，支持多种变体：
 * - 按钮：filled（黑底白字）/ outline（白底带边框）
 * - 价格区域：副标题文本 / 纯价格 / 价格 + 划线原价
 * - 模型额度 / 功能权益：条目数量可变
 * - 推荐方案：包裹渐变容器 + 底部徽标
 *
 * 横向拼接时通过 `headerMinHeight` / `featuresMinHeight` 控制区域最小高度，
 * 让不同条目数量的卡片在视觉上对齐。
 *
 * @example
 * <MsFeePlanCard
 *   title="基础版"
 *   subtitle="广告主免费使用"
 *   buttonText="当前等级"
 *   buttonVariant="outline"
 *   modelFeatures={[...]}
 *   features={[...]}
 * />
 *
 * @example
 * <MsFeePlanCard
 *   title="Pro 标准版"
 *   price={159}
 *   originalPrice={530}
 *   buttonText="立即升级"
 *   recommended
 *   modelFeatures={[
 *     { icon: <MxIconLightning />, label: '基础模型额度', value: '免费' },
 *     { icon: <MxIconTime />, label: '...', value: 260 },
 *     { icon: <MxIconDiamond />, label: 'Pro 模型额度', value: 636, valueGradient: true, subNote: '约生成 1120 张图片' },
 *   ]}
 *   features={[...]}
 *   headerMinHeight={320}
 *   featuresMinHeight={200}
 * />
 */
export declare const MsFeePlanCard: React.FC<MsFeePlanCardProps>;
