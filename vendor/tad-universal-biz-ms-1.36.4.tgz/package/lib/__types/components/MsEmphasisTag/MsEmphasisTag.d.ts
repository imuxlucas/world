import { default as React } from 'react';
import { MsEmphasisTagProps } from './MsEmphasisTag.types';
export declare const MsEmphasisTag: React.FC<MsEmphasisTagProps>;
