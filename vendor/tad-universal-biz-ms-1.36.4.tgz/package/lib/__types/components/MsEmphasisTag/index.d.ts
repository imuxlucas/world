export { MsEmphasisTag } from './MsEmphasisTag';
export type { MsEmphasisTagProps, MsEmphasisTagSize, MsEmphasisTagVariant, } from './MsEmphasisTag.types';
