import { default as React } from 'react';
/** 标签尺寸 */
export type MsEmphasisTagSize = 'sm' | 'md';
/** 标签变体 */
export type MsEmphasisTagVariant = 'default' | 'primary' | 'secondary';
/**
 * MsEmphasisTag 组件配置项
 *
 * 渐变强调型标签：常用于 Pro / 高级 / 限时 等权益强调标识。
 *
 * 变体：
 * - `default` / `secondary`：浅粉渐变背景 + 冷渐变（红→紫）文字
 * - `primary`：实色渐变背景（红→紫）+ 白色文字
 */
export interface MsEmphasisTagProps {
    /**
     * 标签变体
     * - `default` / `secondary`: 浅粉渐变背景 + 冷渐变文字（默认）
     * - `primary`: 实色渐变背景 + 白色文字
     * @default 'default'
     */
    variant?: MsEmphasisTagVariant;
    /**
     * 标签尺寸
     * - `sm`: 14px 高 / 10px 文字，常作为图标角标
     * - `md`: 18px 高 / 12px 文字（默认）
     * - 注：传 `variant="primary"` 时，尺寸被该变体自身的样式覆盖
     * @default 'md'
     */
    size?: MsEmphasisTagSize;
    /**
     * 标签文案
     * @default 'Pro'
     */
    children?: React.ReactNode;
    /**
     * 自定义类名
     */
    className?: string;
    /**
     * 自定义样式
     */
    style?: React.CSSProperties;
}
