import { default as React } from 'react';
/**
 * MsCreditCard 组件配置项
 *
 * 妙思「积分包」小卡片：白底圆角 12，上半展示 AI 星标 + 总积分数 + 描述行
 * （基础积分 + 限时赠送 X，赠送段冷渐变），下半展示价格。
 *
 * 用于「购买积分」弹窗等多选一交互场景；卡片作为可点击单位，
 * 由父组件维护 `selected` 状态。
 */
export interface MsCreditCardProps extends React.HTMLAttributes<HTMLDivElement> {
    /** 总积分数（标题行右侧的 OD 大数字） */
    amount: number;
    /**
     * 基础积分数（描述行的左侧数字）
     * - 与 `giftCredits` 共同组成设计稿默认描述行「{baseCredits} + 限时赠送 {giftCredits}」
     * - 传了 `description` 时可省略
     */
    baseCredits?: number;
    /**
     * 赠送积分数（描述行右侧，使用冷渐变文字，渲染为「限时赠送 X」）
     * - 传了 `description` 时可省略
     */
    giftCredits?: number;
    /**
     * 描述行整体自定义（槽位）
     * - 需要改分隔符、赠送文案或整体结构时传入（如「买 1000 送 282」）
     * - 传入后完全接管描述行，不再读取 `baseCredits` / `giftCredits`
     */
    description?: React.ReactNode;
    /**
     * 价格文案（如「100元」）
     * - 支持 ReactNode，可传自定义结构（如价格 + 划线原价）
     */
    price: React.ReactNode;
    /**
     * 标题行左侧图标
     * @default <MxIconAiStarsFilled size={20} />
     */
    icon?: React.ReactNode;
    /**
     * 是否为当前选中项（多选一交互）
     * @default false
     */
    selected?: boolean;
    /** 点击回调 */
    onClick?: () => void;
    /** 自定义类名（作用在卡片根节点） */
    className?: string;
    /** 自定义样式（作用在卡片根节点） */
    style?: React.CSSProperties;
}
