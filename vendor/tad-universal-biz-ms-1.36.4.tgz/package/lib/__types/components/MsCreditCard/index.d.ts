export { MsCreditCard } from './MsCreditCard';
export type { MsCreditCardProps } from './MsCreditCard.types';
