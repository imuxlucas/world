import { default as React } from 'react';
import { MsCreditCardProps } from './MsCreditCard.types';
/**
 * MsCreditCard（妙思积分包卡片）
 *
 * 白底圆角 12 的小卡片，用于「购买积分」弹窗等多选一交互：
 * - 上半：AI 星标 + 总积分数（OD 数字大号）+ 描述行（基础 + 限时赠送，赠送段冷渐变）
 * - 下半：价格（如「100元」）
 *
 * 作为可点击单位使用，由父组件维护 `selected` 状态。描边环（::before，mask 挖空 1px
 * 渐变环，仅选中态出现）与渐变蒙层（::after）各占一个伪元素图层、以 opacity 淡入淡出
 * （渐变无法参与 transition，直接切只能硬切）；hover 只出这层渐变蒙层、不出描边环，
 * 与选中态同强度，选中时再叠加描边环作为落定标识。伪元素不占布局空间，切换无尺寸抖动。
 *
 * @example
 * <MsCreditCard
 *   amount={1282}
 *   baseCredits={1000}
 *   giftCredits={282}
 *   price="100元"
 *   selected
 *   onClick={() => setSelected(2)}
 * />
 */
export declare const MsCreditCard: React.FC<MsCreditCardProps>;
