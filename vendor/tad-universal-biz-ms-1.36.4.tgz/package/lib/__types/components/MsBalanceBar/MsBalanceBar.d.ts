import { default as React } from 'react';
import { MsBalanceBarProps } from './MsBalanceBar.types';
/**
 * MsBalanceBar（妙思余额/扣费运算条）
 *
 * 依次展示 `label + value` 条目，相邻条目之间自动插入运算符。
 * 运算符固定为**等式**：前项之间用 `-`，最后一项前用 `=`（形如 `A - B = C`）；
 * 需要其他运算符（如 `+` 累计）传 `renderOperator` 完全自定义。
 *
 * **只做纯排布**（inline-flex + gap），不带背景/圆角/内边距，宽度按内容自适应；
 * 需要灰底壳或两端对齐由外层负责。
 *
 * @example
 * // 「账户余额 - 本次扣费 = 生成后余额」
 * <div className="flex items-center justify-between rounded-lg bg-neutral-100 px-3 py-2">
 *   <MsBalanceBar
 *     items={[
 *       { key: 'balance', label: '账户余额 (元)', value: '¥108.36', minWidth: 72 },
 *       { key: 'fee',     label: '本次扣费 (元)', value: '100.00',  minWidth: 72 },
 *       { key: 'after',   label: '生成后余额 (元)', value: '¥8.36',  minWidth: 84 },
 *     ]}
 *   />
 * </div>
 */
export declare const MsBalanceBar: React.FC<MsBalanceBarProps>;
