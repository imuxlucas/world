import { default as React } from 'react';
/** 单条余额条目 */
export interface MsBalanceBarItem {
    /** 列表项唯一标识，用作 React key；未提供时回退到 label 索引 */
    key?: string | number;
    /** 单项标签，如 "账户余额 (元)"、"本次扣费 (元)" */
    label: React.ReactNode;
    /**
     * 单项数值内容。
     * - 支持字符串或 ReactNode（可含 `¥` 前缀、单位、富文本等）
     * - 若为字符串且以数字负数形式表示（`Number(value) < 0`），
     *   在未显式指定 `negative` 时会自动应用负值高亮
     */
    value: React.ReactNode;
    /**
     * 显式标记为「负值」以应用红色高亮。
     * 未传时组件对字符串型 value 自动按 `Number(value) < 0` 判定。
     */
    negative?: boolean;
    /**
     * 单项的最小宽度（如 72、'72px'、'6rem'），用于稳定列宽避免抖动。
     * 数字将按 px 处理。
     */
    minWidth?: number | string;
}
/**
 * MsBalanceBar 组件配置项
 *
 * 妙思「金额/余额运算条」：一行排列多个 label + value 条目，
 * 相邻条目之间自动插入运算符（`-` / `=`），常见于扣费确认、账户余额换算等场景。
 *
 * **只负责排布**（inline-flex + gap + 运算符），不包含背景块、圆角、内边距等外观样式，
 * 宽度按内容自适应、不撑满父容器。若需要灰底圆角壳或两端对齐，请由调用方在外层套壳或
 * 通过 `className` 覆盖（外部选择器天然优先级更高）。
 */
export interface MsBalanceBarProps {
    /** 余额条目列表；至少 1 项才会渲染 */
    items: MsBalanceBarItem[];
    /**
     * 完全自定义运算符渲染（优先级高于默认的等式规则）。
     * @param index 当前运算符**左侧条目**的索引；范围 `[0, items.length - 2]`
     * @param total 条目总数
     */
    renderOperator?: (index: number, total: number) => React.ReactNode;
    /** 自定义类名（作用在根节点） */
    className?: string;
    /** 自定义样式（作用在根节点） */
    style?: React.CSSProperties;
}
