import { default as React } from 'react';
/**
 * MsAiInputShell（妙思 AI 输入框外壳）配置项
 *
 * 外壳是一张卡片，**把输入框包在自己里面**：顶部按需拼装提示条 / 分区 / 排序列表 /
 * 分割线，底部紧接输入框。卡片靠 `padding: 0 overhang overhang` 让输入框四周露出
 * `overhang` 像素的卡片底色，无需任何绝对定位或高度测量。
 *
 * ## 卡片皮肤
 *
 * 底色、描边、投影不做成 prop，直接覆盖 CSS 变量即可——`style` 内联、`className`
 * 里写、或在任意祖先上写（变量可继承）都行：
 *
 * | 变量 | 默认 |
 * |---|---|
 * | `--ms-ai-input-shell-bg` | `var(--mx-color-neutral-100)` 浅灰 |
 * | `--ms-ai-input-shell-stroke-color` | `transparent`（无描边） |
 * | `--ms-ai-input-shell-stroke-width` | `0.5px` |
 * | `--ms-ai-input-shell-shadow` | `0 0 32px rgba(0,0,0,0.06)` |
 *
 * ```tsx
 * // 落在灰底页面上时改白底 + 一圈描边，把卡片从背景里拎出来
 * <MsAiInputShell
 *   style={{
 *     '--ms-ai-input-shell-bg': 'var(--mx-color-neutral-0)',
 *     '--ms-ai-input-shell-stroke-color': 'var(--mx-color-neutral-tp-150)',
 *   } as React.CSSProperties}
 * />
 * ```
 *
 * 组件内部**不给这些变量赋值**，默认值只作为 `var()` 的兜底存在——否则
 * class 覆盖要拼特异性，写成内联样式更会把 class 彻底盖死。
 *
 * ## 宿主必须遵守的几何契约
 *
 * **定位与尺寸动画一律写在外壳上，输入框在外壳内保持 `position: static; width: 100%`。**
 *
 * 即 `position: fixed/sticky/absolute`、`left: 50%` + `translateX(-50%)`、宽度与
 * 圆角的过渡，全部挂到本组件（或它的直接父级）上。输入框自己不要再定位——否则
 * `fixed` 会逃出外壳，卡片就包不住它了。
 *
 * ```tsx
 * <MsAiInputShell
 *   collapsed={isCollapsed}
 *   radius={isCollapsed ? 44 : 16}
 *   className="fixed bottom-5 left-1/2 -translate-x-1/2 transition-[width]"
 *   style={{ width: isCollapsed ? 640 : 860 }}
 * >
 *   <MsAiInputShell.Hint icon={<GradientStar />}>今日额度不足，…</MsAiInputShell.Hint>
 *   <MsAiInputShell.Separator />
 *   <MsAiInputShell.Section title="任务队列" count={tasks.length}>
 *     <MsAiInputShell.SortList … />
 *   </MsAiInputShell.Section>
 *   <MyInputBox />
 * </MsAiInputShell>
 * ```
 */
export interface MsAiInputShellProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'children'> {
    /** 容器类名 */
    className?: string;
    /** 容器样式 */
    style?: React.CSSProperties;
    /**
     * 收起态：为 true 时所有拼装单元收起退场（高度动画到 0），只保留输入框。
     *
     * 用于输入框滚动收起成胶囊的场景——对齐妙思现有做法：收起态不展示任何顶部信息。
     */
    collapsed?: boolean;
    /**
     * 卡片圆角（px），默认 16。
     *
     * 需要跟随宿主状态做动画时，把过渡写在 `className`/`style` 上即可
     * （本组件的圆角是 CSS 变量驱动的普通属性，可直接 transition）。
     */
    radius?: number;
    /**
     * 卡片相对输入框向外露出的像素（左 / 右 / 下三边），默认 1。
     *
     * 实现方式是卡片自身的 padding，所以输入框只要 `width: 100%` 就会自动内缩。
     */
    overhang?: number;
    /**
     * 拼装区内容的左右边距（px），默认 `max(16, radius)`。
     *
     * 提示条、分区头、行、分割线共用这一个值。默认跟随圆角是因为圆角越大，
     * 卡片四角切掉的面积越多，内容贴着边会显得挤——大圆角输入框（首页 24px）
     * 自然拿到 24px 边距，小圆角（画布 12px）保持 16px 下限。
     */
    paddingX?: number;
    /**
     * 紧凑模式，默认 false。
     *
     * 只收纵向尺寸，横向边距与色块几何不变：
     *
     * | | 默认 | 紧凑 |
     * |---|---|---|
     * | 提示条 | 46px | 40px |
     * | 分区头 | 40px | 36px |
     * | 内容行 | 40px | 36px |
     *
     * 都是靠 padding 收，不写死 height——内容换行或图标变大时仍会自然长高。
     * 小圆角卡片（画布侧栏这类空间紧张的场景）适合开；大圆角的首页 / 悬浮框
     * 空间宽裕，保持默认更舒展。
     */
    compact?: boolean;
    /**
     * 拼装区是否浮在输入框上方、**不占据布局高度**，默认 false。
     *
     * - `false`（流内）：拼装区把输入框往下推，外层容器的高度包含它。
     *   结果页那种「用 ResizeObserver 量输入框高度去撑列表底部留白」的场景必须用这个。
     * - `true`（浮层）：只有输入框占高度，拼装区绝对定位在它正上方，会盖住上方的
     *   技能卡片、标题等内容——输入框位置完全不动，对齐妙思旧提示条的行为。
     *
     * 两种形态的卡片外观一致：浮层态下拼装区自带上半截卡片（上圆角），
     * 与下半截在接缝处严丝合缝。
     */
    overlay?: boolean;
    /**
     * 强制外壳显隐。
     *
     * 缺省时为自动：**有拼装单元渲染且非收起态**才画卡片；一个单元都没有时卡片
     * 完全隐身（背景透明、padding 归零），输入框回到独立形态，无需宿主自己算显隐条件。
     */
    shell?: boolean;
    /**
     * 子节点：按书写顺序「若干拼装内容 + 输入框」。
     *
     * 外壳要把它们切成拼装区与输入框两段（浮层形态下两段定位方式不同）。切分规则：
     *
     * 1. 有 `<MsAiInputShell.Input>` 插槽时，**认插槽**——插槽内是输入框，其余全归拼装区。
     *    使用方通常会把提示条、队列组合成自己的业务组件，外壳认不出那是什么，
     *    所以只能认输入框。**拼装内容被自己的组件包着时必须这样写**，否则 `overlay`
     *    分不出拼装区，整块仍会占据高度。
     * 2. 没有插槽时退回认拼装单元——`Hint` / `Section` / `SortList` / `Separator` /
     *    `Unit` 归拼装区，其余留在流内。适合把单元直接平铺的简单写法。
     */
    children?: React.ReactNode;
}
/**
 * 外壳向拼装单元下发的上下文
 *
 * 通过 {@link useMsAiInputShell} 读取。在外壳之外读到的是 `null`。
 */
export interface MsAiInputShellContextValue {
    /** 外壳当前是否处于收起态 */
    collapsed: boolean;
    /** 外壳当前是否真的画出了卡片（背景 + 露边） */
    active: boolean;
    /**
     * 拼装区内容的左右边距（px），即 {@link MsAiInputShellProps.paddingX} 的最终取值。
     *
     * 排序列表要用它把 `--ms-ai-input-shell-padding-x` 写回到行上——拖拽中的行会被
     * react-movable 移到 `document.body` 下，脱离外壳子树后拿不到定义在外壳根节点上的
     * CSS 变量，`padding: 8px var(--未定义)` 会整条失效变成 0。
     */
    paddingX: number;
    /** 外壳当前是否处于紧凑模式，见 {@link MsAiInputShellProps.compact} */
    compact: boolean;
    /**
     * 注册一个「已渲染的拼装单元」，返回注销函数。
     *
     * 注册数 > 0 是外壳自动显隐的依据；由 {@link MsAiInputShellUnitProps.register} 控制。
     */
    register: () => () => void;
}
/**
 * MsAiInputShellUnit（拼装单元通用壳）配置项
 *
 * Hint / Section / SortList 内部都用它包一层，负责两件事：
 * 向外壳注册（决定卡片显隐）、收起态的高度动画（`grid-template-rows: 1fr → 0fr`，
 * 不需要测量高度）。
 *
 * 需要往外壳里塞自定义内容时也可以直接用它，从而获得同样的注册与收起行为。
 */
export interface MsAiInputShellUnitProps {
    /** 单元类名 */
    className?: string;
    /** 单元样式 */
    style?: React.CSSProperties;
    /**
     * 是否参与外壳显隐的统计，默认 true。
     *
     * 分割线这类「自己不构成内容」的单元传 false——只有分割线时卡片不应该出现。
     */
    register?: boolean;
    /**
     * 是否展开，默认跟随外壳的 `collapsed` 取反。
     *
     * 传入后与外壳收起态取「与」：外壳收起时一律收起。
     */
    open?: boolean;
    /** 单元内容 */
    children?: React.ReactNode;
}
/**
 * MsAiInputShellInput（输入框插槽）配置项
 *
 * 只是个标记，**本身不产生任何 DOM**，包上它不影响布局。作用是告诉外壳
 * 「这个才是输入框，其余子节点都是拼装区」——见 {@link MsAiInputShellProps.children}。
 */
export interface MsAiInputShellInputProps {
    /** 输入框 */
    children?: React.ReactNode;
}
/**
 * MsAiInputShellHint（外壳内的提示条）配置项
 *
 * 只有「图标 + 文案 + 关闭按钮」三段内容，**没有任何背景、边框、圆角与投影**
 * ——这些一律由外壳承担。需要独立悬浮在输入框顶部的旧形态，请继续用 `MsAiInputHint`。
 */
export interface MsAiInputShellHintProps {
    /** 提示条类名 */
    className?: string;
    /** 提示条样式 */
    style?: React.CSSProperties;
    /** 左侧图标（ReactNode，完全自定义，如渐变 AI star）；不传则不显示 */
    icon?: React.ReactNode;
    /** 提示文案（ReactNode，可内嵌可点击链接、气泡等） */
    children?: React.ReactNode;
    /** 受控显隐 */
    visible?: boolean;
    /** 非受控初始显隐，默认 true */
    defaultVisible?: boolean;
    /** 点击关闭按钮的回调（受控 / 非受控都会触发） */
    onClose?: () => void;
    /** 是否显示关闭按钮，默认 true */
    closable?: boolean;
    /** 自定义关闭图标，默认 `MxIconXmark` */
    closeIcon?: React.ReactNode;
    /** 关闭按钮的原生 HTML 属性透传（如 data-* 埋点、aria-label 等） */
    closeButtonProps?: React.ButtonHTMLAttributes<HTMLButtonElement> & {
        [dataAttr: `data-${string}`]: unknown;
    };
}
/**
 * MsAiInputShellSection（外壳内的可折叠分区）配置项
 *
 * 一个带标题头的分区，如「任务队列 (3)」。头部可点击折叠，折叠态只留标题行。
 * 分区自身无背景，只有头部 hover 时有一层浅底色作为可点反馈。
 */
export interface MsAiInputShellSectionProps {
    /** 分区类名 */
    className?: string;
    /** 分区样式 */
    style?: React.CSSProperties;
    /** 标题（ReactNode） */
    title?: React.ReactNode;
    /** 标题后的计数，渲染为 `标题 (count)`；不传则不显示 */
    count?: number;
    /** 头部右侧插槽（如「并行会话数已满，排队中」这类状态提示） */
    extra?: React.ReactNode;
    /** 是否可折叠，默认 true；false 时头部不可点、不显示折叠箭头 */
    collapsible?: boolean;
    /** 受控折叠态 */
    collapsed?: boolean;
    /** 非受控初始折叠态，默认 false（展开） */
    defaultCollapsed?: boolean;
    /** 折叠态变化回调（受控 / 非受控都会触发） */
    onCollapsedChange?: (collapsed: boolean) => void;
    /** 头部按钮的原生 HTML 属性透传（如 data-* 埋点） */
    headerProps?: React.ButtonHTMLAttributes<HTMLButtonElement> & {
        [dataAttr: `data-${string}`]: unknown;
    };
    /** 分区内容 */
    children?: React.ReactNode;
}
/**
 * 拖拽把手属性
 *
 * 由 {@link MsAiInputShellSortListProps.renderItem} 下发。把它展开到任意元素上，
 * 该元素就成为这一行的拖拽把手：
 *
 * ```tsx
 * renderItem={(task, { handleProps }) => (
 *   <MsAiInputShell.Row leading={<span {...handleProps}><MyDragIcon /></span>}>
 *     {task.label}
 *   </MsAiInputShell.Row>
 * )}
 * ```
 *
 * 不展开到任何元素时，整行都不可拖拽（键盘排序仍可用）。
 */
export interface MsAiInputShellDragHandleProps {
    /** react-movable 识别把手用的标记属性 */
    'data-movable-handle': true;
}
/** {@link MsAiInputShellSortListProps.renderItem} 的第二个参数 */
export interface MsAiInputShellSortListItemContext {
    /** 当前行在列表中的下标 */
    index: number;
    /** 当前行是否正在被拖拽 */
    isDragged: boolean;
    /** 当前行是否被键盘选中（无障碍排序中） */
    isSelected: boolean;
    /** 拖拽把手属性，展开到把手元素上 */
    handleProps: MsAiInputShellDragHandleProps;
}
/**
 * MsAiInputShellSortList（外壳内的可拖拽排序列表）配置项
 *
 * **只负责排序行为，不负责任何行内容**：行怎么画、把手长什么样、右侧有哪些操作按钮，
 * 全部由 `renderItem` 决定。需要现成的行样式时可以用 {@link MsAiInputShellRowProps}，
 * 不想用就完全自己写。
 */
export interface MsAiInputShellSortListProps<T> {
    /** 列表类名 */
    className?: string;
    /** 列表样式 */
    style?: React.CSSProperties;
    /** 列表数据 */
    items: T[];
    /** 取每项的 React key */
    getKey: (item: T, index: number) => React.Key;
    /**
     * 排序回调，回传**排序后的完整数组**（已 immutable 处理，可直接 setState）。
     *
     * 第二个参数给出原始下标，便于埋点或做增量更新。
     */
    onReorder: (next: T[], meta: {
        oldIndex: number;
        newIndex: number;
    }) => void;
    /** 渲染单行；第二个参数携带拖拽把手属性与拖拽态 */
    renderItem: (item: T, ctx: MsAiInputShellSortListItemContext) => React.ReactNode;
    /** 禁用拖拽，默认 false */
    disabled?: boolean;
    /**
     * 列表最大高度，超出后滚动。默认 140（px）。
     *
     * 140 的来历：`Row` 行高固定 40px（22px 内容 + 上下各 9px padding），
     * 140 = 40 × 3.5，即 3 条整条 + 第 4 条露出一半——露半条是在暗示「下面还有」，
     * 比卡在整条边界更容易让人发现可以滚。
     *
     * 行的高度被 `renderItem` 改过时按 `行高 * 3.5` 重算即可。
     * 传字符串走原生 CSS，`'none'` 表示不限高（列表有多长就展开多长）。
     */
    maxHeight?: number | string;
    /** 拖拽时锁定为纯垂直移动，默认 true */
    lockVertically?: boolean;
    /**
     * 拖拽浮层的挂载容器，默认 `document.body`。
     *
     * 外壳处在 `transform` 祖先内导致浮层错位时，可传入就近的定位容器。
     */
    container?: Element | null;
    /**
     * 滚动渐隐蒙版的最大高度（px），默认 24；传 0 关闭。
     *
     * 列表上/下方还有内容没露出来时，在对应边缘做一层「内容淡出到透明」的遮罩，
     * 半遮住一行来暗示「还能滚」。遮罩高度取 `min(该方向剩余可滚动距离, fadeSize)`，
     * 所以滚到顶/底时自然收到 0，不需要额外的显隐判断，也不会突然消失。
     *
     * 实现用 `mask-image`（让内容淡到透明、露出卡片底色），而不是叠一层背景色浮层——
     * 不与卡片底色耦合，也不额外增加 DOM。
     */
    fadeSize?: number;
    /**
     * 拖拽中那一行的打底色，默认卡片底色 `var(--mx-color-neutral-100, #f2f2f2)`。
     *
     * 行的 hover / 拖拽态底色是半透明 token（`--mx-color-neutral-tp-100`），在卡片里
     * 压着卡片底色看没问题；但拖拽行会被移到 `document.body` 下，下面就变成页面内容了，
     * 半透明会直接透出来。这里在行下面垫一层不透明卡片色，半透明 tint 叠在上面，
     * 合成结果与它在卡片里 hover 时完全一致。
     *
     * 走内联样式，因此 portal 出去也带得走。外壳卡片底色被改过时同步改这里。
     */
    dragBackground?: string;
    /**
     * 拖拽中那一行的 `z-index`，默认 9999。
     *
     * 拖拽行会被移到 `document.body` 下，而 react-movable 不给它任何 z-index。
     * 页面里凡是带 z-index 的定位元素（面板、工具条等）只要和它同处根层叠上下文，
     * 就会把它盖住——表现为「一拖就不见了」。默认值足以压过常规面板；
     * 站点自身层级排得很高时按需调大。
     */
    dragZIndex?: number;
}
/**
 * MsAiInputShellRow（外壳内的通用行）配置项
 *
 * 现成的一行样式：左把手槽 + 中间内容（单行截断） + 右操作槽，hover 有浅底色。
 * 纯展示组件，不含任何排序或业务逻辑；三个槽位都是 ReactNode，随便塞。
 */
export interface MsAiInputShellRowProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'children' | 'title'> {
    /** 行类名 */
    className?: string;
    /** 行样式 */
    style?: React.CSSProperties;
    /** 左侧插槽，通常放拖拽把手 */
    leading?: React.ReactNode;
    /** 右侧插槽，通常放操作按钮组 */
    actions?: React.ReactNode;
    /**
     * 是否处于激活态（拖拽中 / 选中），底色与 hover 一致。
     *
     * 拖拽中显式传 true，而不是依赖 `:hover`——指针离开原位后 hover 就丢了。
     */
    active?: boolean;
    /** 中间主内容，默认单行截断 */
    children?: React.ReactNode;
}
/**
 * MsAiInputShellSeparator（外壳内的分割线）配置项
 *
 * 左右按外壳的 `paddingX` 内缩，与提示条/分区/行的左右边缘对齐，避免整条横跨卡片。
 * 分割线不参与外壳显隐统计——只有分割线时卡片不会出现。
 */
export interface MsAiInputShellSeparatorProps {
    /** 分割线类名 */
    className?: string;
    /** 分割线样式 */
    style?: React.CSSProperties;
}
