import { default as React } from 'react';
import { MsAiInputShellSectionProps } from './MsAiInputShell.types';
/**
 * MsAiInputShellSection（外壳内的可折叠分区）
 *
 * 带标题头的一段内容，如「任务队列 (3)」。头部可点击折叠，右侧 `extra` 插槽可以放
 * 状态提示。分区自身无背景，只有头部 hover 时给一层浅底色作为可点反馈。
 *
 * ```tsx
 * <MsAiInputShell.Section
 *   title="任务队列"
 *   count={tasks.length}
 *   extra={queueFull && <span><InfoIcon />并行会话数已满，排队中</span>}
 * >
 *   <MsAiInputShell.SortList … />
 * </MsAiInputShell.Section>
 * ```
 */
export declare const MsAiInputShellSection: React.FC<MsAiInputShellSectionProps>;
