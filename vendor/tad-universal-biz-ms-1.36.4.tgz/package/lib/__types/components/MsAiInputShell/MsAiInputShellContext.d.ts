import { default as React } from 'react';
import { MsAiInputShellContextValue } from './MsAiInputShell.types';
/**
 * 外壳上下文
 *
 * 外壳之外读到 `null`——拼装单元据此判断自己是不是被单独使用了（此时不注册、不做收起动画，
 * 仍然正常渲染内容，便于在 storybook 或过渡期单独摆放）。
 */
export declare const MsAiInputShellContext: React.Context<MsAiInputShellContextValue | null>;
/**
 * 读取外壳上下文
 *
 * 输入框可以用它感知外壳状态，例如外壳画出卡片时收掉自己的外投影
 * （投影视觉由卡片承担，两层叠加会显脏）：
 *
 * ```tsx
 * const shell = useMsAiInputShell();
 * <div style={{ boxShadow: shell?.active ? 'none' : '0 0 32px rgba(0,0,0,.06)' }} />
 * ```
 */
export declare function useMsAiInputShell(): MsAiInputShellContextValue | null;
/**
 * 把组件标记为输入框插槽
 *
 * 外壳要把子节点切成「拼装区」和「输入框」两段——浮层形态下这两段定位方式不同，
 * 必须分得开。**认输入框、而不是认拼装单元**：使用方几乎一定会把提示条、队列组合成
 * 自己的业务组件（外壳看到的就是个普通组件，认不出来），但输入框永远是外壳里
 * 确定的那一个节点。
 */
export declare function markShellInput<C>(component: C): C;
/** 判断子节点是不是输入框插槽 */
export declare function isShellInputElement(node: React.ReactNode): boolean;
/**
 * 把组件标记为拼装单元
 *
 * 仅用于**没有写 `<MsAiInputShell.Input>` 插槽**时的兜底切分（比如 storybook 里
 * 把单元直接平铺、输入框裸写在最后的简单写法）。正式接入请用 Input 插槽。
 */
export declare function markShellUnit<C>(component: C): C;
/** 判断子节点是不是拼装单元（非法节点、纯文本、条件渲染出的 false 都返回 false） */
export declare function isShellUnitElement(node: React.ReactNode): boolean;
export declare function useRegisterShellUnit(enabled: boolean): void;
