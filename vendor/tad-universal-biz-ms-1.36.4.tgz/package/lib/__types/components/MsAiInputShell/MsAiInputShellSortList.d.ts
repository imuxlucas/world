import { default as React } from 'react';
import { MsAiInputShellSortListProps } from './MsAiInputShell.types';
/**
 * MsAiInputShellSortList（外壳内的可拖拽排序列表）
 *
 * **只负责排序行为，不负责任何行内容。** 行怎么画、把手放哪、右侧有哪些操作按钮，
 * 全部交给 `renderItem`；组件唯一的契约是把 `handleProps` 展开到你想当把手的元素上。
 *
 * ```tsx
 * <MsAiInputShell.SortList
 *   items={tasks}
 *   getKey={(t) => t.id}
 *   onReorder={(next) => setTasks(next)}
 *   renderItem={(task, { handleProps, isDragged }) => (
 *     <MsAiInputShell.Row
 *       active={isDragged}
 *       leading={<span {...handleProps}><MyDragIcon /></span>}
 *       actions={<><PinBtn id={task.id} /><EditBtn id={task.id} /><DeleteBtn id={task.id} /></>}
 *     >
 *       {task.label}
 *     </MsAiInputShell.Row>
 *   )}
 * />
 * ```
 *
 * 拖拽中的行会被 react-movable 移到 `container`（默认 `document.body`）下的浮层里，
 * 因此行的样式必须来自全局类名或内联样式，不能依赖祖先选择器。
 */
export declare function MsAiInputShellSortList<T>({ className, style, items, getKey, onReorder, renderItem, disabled, maxHeight, lockVertically, container, fadeSize, dragBackground, dragZIndex, }: MsAiInputShellSortListProps<T>): React.ReactElement | null;
