import { default as React } from 'react';
import { MsAiInputShellRowProps } from './MsAiInputShell.types';
/**
 * MsAiInputShellRow（外壳内的通用行）
 *
 * 现成的一行样式：左把手槽 + 中间内容（单行截断） + 右操作槽，hover 有浅底色。
 * 纯展示组件，不含排序或业务逻辑——`MsAiInputShell.SortList` 不强制用它，
 * 想完全自己画一行也完全可以。
 *
 * ```tsx
 * <MsAiInputShell.Row
 *   active={isDragged}
 *   leading={<span {...handleProps}><MyDragIcon /></span>}
 *   actions={<><PinBtn /><EditBtn /><DeleteBtn /></>}
 * >
 *   {task.label}
 * </MsAiInputShell.Row>
 * ```
 */
export declare const MsAiInputShellRow: React.FC<MsAiInputShellRowProps>;
