import { default as React } from 'react';
import { MsAiInputShellHintProps } from './MsAiInputShell.types';
/**
 * MsAiInputShellHint（外壳内的提示条）
 *
 * 只有「图标 + 文案 + 关闭按钮」三段内容，**不带任何背景、边框、圆角与投影**——
 * 卡片外观一律由外壳承担，这样它才能和分区、排序列表拼在同一张卡片里。
 *
 * 需要独立悬浮在输入框顶部（自带上移 transform、自带卡片外观）的旧形态，
 * 请继续使用 `MsAiInputHint`，那个组件保持原样不变。
 *
 * ```tsx
 * <MsAiInputShell.Hint icon={<GradientStar />} onClose={report}>
 *   今日额度不足，
 *   <span className="cursor-pointer font-medium text-[var(--mx-color-blue-800)]" onClick={goAlloc}>
 *     关联广告账户
 *   </span>
 *   后可继续生成
 * </MsAiInputShell.Hint>
 * ```
 */
export declare const MsAiInputShellHint: React.FC<MsAiInputShellHintProps>;
