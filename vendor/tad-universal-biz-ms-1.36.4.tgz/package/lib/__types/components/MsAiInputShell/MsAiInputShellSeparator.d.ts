import { default as React } from 'react';
import { MsAiInputShellSeparatorProps } from './MsAiInputShell.types';
/**
 * MsAiInputShellSeparator（外壳内的分割线）
 *
 * 左右按外壳的 `paddingX`（默认 `max(16, radius)`）内缩，与内容区左右边缘对齐，避免整条横跨卡片。
 *
 * **不参与外壳显隐统计**——只剩分割线时卡片不会出现，因此拼装时可以放心地
 * 无条件写在两个可能为空的单元之间。
 */
export declare const MsAiInputShellSeparator: React.FC<MsAiInputShellSeparatorProps>;
