import { default as React } from 'react';
import { MsAiInputShellInputProps } from './MsAiInputShell.types';
/**
 * MsAiInputShellInput（输入框插槽）
 *
 * 把输入框包一层，告诉外壳「这个才是输入框，其余都是拼装区」。
 * **本身不产生任何 DOM**，只是个标记，所以包上它不会影响任何布局。
 *
 * ```tsx
 * <MsAiInputShell overlay>
 *   <MyHintAndQueue />              // 业务侧自己组合的拼装内容
 *   <MsAiInputShell.Input>
 *     <MyInputBox />
 *   </MsAiInputShell.Input>
 * </MsAiInputShell>
 * ```
 *
 * **拼装内容被自己的业务组件包着时必须写**——外壳只能看到那个组件、认不出里面是什么。
 * 把单元直接平铺在外壳里时可以省略（外壳会退回认单元的兜底规则）。
 *
 * 流内形态下省略最多是分层不同、视觉一致；`overlay` 形态下省略会导致拼装区分不出来，
 * 整块仍然占据高度（就是没生效）。
 */
export declare const MsAiInputShellInput: React.FC<MsAiInputShellInputProps>;
