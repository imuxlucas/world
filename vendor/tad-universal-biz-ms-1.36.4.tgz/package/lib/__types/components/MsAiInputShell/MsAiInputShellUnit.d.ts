import { default as React } from 'react';
import { MsAiInputShellUnitProps } from './MsAiInputShell.types';
/**
 * MsAiInputShellUnit（拼装单元通用壳）
 *
 * 外壳里每个拼装单元的公共外层，做两件事：
 *
 * 1. **向外壳注册**——注册数 > 0 外壳才画卡片，宿主不用自己算显隐条件；
 * 2. **收起动画**——用 `grid-template-rows: 1fr → 0fr` 把高度收到 0，
 *    不需要 ResizeObserver 或 `scrollHeight` 之类的测量，也不会在内容变化时失准。
 *
 * 自定义内容想获得同样的行为，直接用它包一层即可。
 */
export declare const MsAiInputShellUnit: React.FC<MsAiInputShellUnitProps>;
