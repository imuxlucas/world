import { default as React } from 'react';
import { MsAiInputShellProps } from './MsAiInputShell.types';
import { MsAiInputShellSortList } from './MsAiInputShellSortList';
/**
 * 妙思 AI 输入框外壳。子组件：
 *
 * - `MsAiInputShell.Hint` 提示条（图标 + 文案 + 关闭，无背景）
 * - `MsAiInputShell.Section` 可折叠分区（如「任务队列 (3)」）
 * - `MsAiInputShell.SortList` 拖拽排序列表（只管排序，行内容全自定义）
 * - `MsAiInputShell.Row` 通用行样式（把手槽 / 内容 / 操作槽）
 * - `MsAiInputShell.Separator` 内缩分割线
 * - `MsAiInputShell.Unit` 拼装单元通用壳（自定义内容用它包一层即可获得注册与收起行为）
 * - `MsAiInputShell.Input` 输入框插槽（不产生 DOM；拼装内容被自己的组件包着时必须写）
 */
export declare const MsAiInputShell: React.FC<MsAiInputShellProps> & {
    Hint: React.FC<import('./MsAiInputShell.types').MsAiInputShellHintProps>;
    Section: React.FC<import('./MsAiInputShell.types').MsAiInputShellSectionProps>;
    SortList: typeof MsAiInputShellSortList;
    Row: React.FC<import('./MsAiInputShell.types').MsAiInputShellRowProps>;
    Separator: React.FC<import('./MsAiInputShell.types').MsAiInputShellSeparatorProps>;
    Unit: React.FC<import('./MsAiInputShell.types').MsAiInputShellUnitProps>;
    Input: React.FC<import('./MsAiInputShell.types').MsAiInputShellInputProps>;
};
