import { default as React } from 'react';
import { MsAiQuotaDetailFooterActionProps } from './MsAiQuotaDetail.types';
/**
 * MsAiQuotaDetail.FooterAction（底部操作链接）
 *
 * 默认展示文案 + 右侧箭头，可配置 onClick / href。
 */
export declare const MsAiQuotaDetailFooterAction: React.FC<MsAiQuotaDetailFooterActionProps>;
