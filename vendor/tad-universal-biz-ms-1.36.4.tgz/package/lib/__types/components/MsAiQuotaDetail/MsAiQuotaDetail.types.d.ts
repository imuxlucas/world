import { default as React } from 'react';
export interface MsAiQuotaDetailProps {
    children?: React.ReactNode;
    className?: string;
    style?: React.CSSProperties;
}
export interface MsAiQuotaDetailHeaderProps {
    /** 主标题 */
    title: React.ReactNode;
    /** 标题是否使用渐变文字色 */
    titleGradient?: boolean;
    /** 副标题（展示在主标题下方） */
    subtitle?: React.ReactNode;
    /** 右侧操作区（传入任意 ReactNode） */
    action?: React.ReactNode;
    className?: string;
    style?: React.CSSProperties;
}
export interface MsAiQuotaDetailDataItemProps {
    /** 左侧图标（MxIcon 组件或其他 ReactNode） */
    icon: React.ReactNode;
    /** 标签 */
    label: React.ReactNode;
    /** 数值 */
    value: React.ReactNode;
    /** 缩进的子项（通常为 MsAiQuotaDetail.SubItem） */
    children?: React.ReactNode;
    className?: string;
    style?: React.CSSProperties;
}
export interface MsAiQuotaDetailSubItemProps {
    /** 标签 */
    label: React.ReactNode;
    /** 数值 */
    value: React.ReactNode;
    className?: string;
    style?: React.CSSProperties;
}
export interface MsAiQuotaDetailFooterProps {
    children?: React.ReactNode;
    className?: string;
    style?: React.CSSProperties;
}
export interface MsAiQuotaDetailFooterActionProps {
    /** 链接文案 */
    label: React.ReactNode;
    /** 点击回调 */
    onClick?: () => void;
    /** 链接地址（提供时渲染为 a 标签） */
    href?: string;
    /** 是否显示右侧箭头 */
    arrow?: boolean;
    className?: string;
    style?: React.CSSProperties;
}
