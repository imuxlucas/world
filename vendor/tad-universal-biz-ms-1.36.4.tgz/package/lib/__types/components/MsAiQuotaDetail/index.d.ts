export { MsAiQuotaDetail } from './MsAiQuotaDetail';
export type { MsAiQuotaDetailProps, MsAiQuotaDetailHeaderProps, MsAiQuotaDetailDataItemProps, MsAiQuotaDetailSubItemProps, MsAiQuotaDetailFooterProps, MsAiQuotaDetailFooterActionProps, } from './MsAiQuotaDetail.types';
