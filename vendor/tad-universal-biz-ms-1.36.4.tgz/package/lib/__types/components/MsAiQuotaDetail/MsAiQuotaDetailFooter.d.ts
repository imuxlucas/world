import { default as React } from 'react';
import { MsAiQuotaDetailFooterProps } from './MsAiQuotaDetail.types';
/**
 * MsAiQuotaDetail.Footer（底部容器）
 *
 * 纯容器，children 自由组合。
 */
export declare const MsAiQuotaDetailFooter: React.FC<MsAiQuotaDetailFooterProps>;
