import { default as React } from 'react';
import { MsAiQuotaDetailSubItemProps } from './MsAiQuotaDetail.types';
/**
 * MsAiQuotaDetail.SubItem（缩进子数据项）
 *
 * 用于 MsAiQuotaDetail.DataItem 内部，展示标签和数值。
 */
export declare const MsAiQuotaDetailSubItem: React.FC<MsAiQuotaDetailSubItemProps>;
