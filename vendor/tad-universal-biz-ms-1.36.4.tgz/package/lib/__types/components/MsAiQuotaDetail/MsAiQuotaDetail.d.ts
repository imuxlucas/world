import { default as React } from 'react';
import { MsAiQuotaDetailProps } from './MsAiQuotaDetail.types';
import { MsAiQuotaDetailHeader } from './MsAiQuotaDetailHeader';
import { MsAiQuotaDetailDataItem } from './MsAiQuotaDetailDataItem';
import { MsAiQuotaDetailSubItem } from './MsAiQuotaDetailSubItem';
import { MsAiQuotaDetailFooter } from './MsAiQuotaDetailFooter';
import { MsAiQuotaDetailFooterAction } from './MsAiQuotaDetailFooterAction';
/**
 * MsAiQuotaDetail（妙思 AI 额度详情面板）
 *
 * Compound Component 容器，通过子组件组合构建面板内容。
 * 连续 DataItem 自动包裹进 __data-list，各 section 之间自动插入分隔线。
 *
 * @example
 * <MsAiQuotaDetail>
 *   <MsAiQuotaDetail.Header title="..." titleGradient subtitle="..." action={<MxButton>详情</MxButton>} />
 *   <MsAiQuotaDetail.DataItem icon={<MxIconLightning size={16} />} label="基础模型额度" value={80} />
 *   <MsAiQuotaDetail.DataItem icon={<MxIconDiamondLightningFilled size={16} />} label="Pro 模型额度" value={701}>
 *     <MsAiQuotaDetail.SubItem label="套餐额度" value={636} />
 *   </MsAiQuotaDetail.DataItem>
 *   <MsAiQuotaDetail.Footer>
 *     <MsAiQuotaDetail.FooterAction label="账单明细" onClick={...} />
 *   </MsAiQuotaDetail.Footer>
 * </MsAiQuotaDetail>
 */
declare const MsAiQuotaDetailBase: React.FC<MsAiQuotaDetailProps>;
type MsAiQuotaDetailComponent = typeof MsAiQuotaDetailBase & {
    Header: typeof MsAiQuotaDetailHeader;
    DataItem: typeof MsAiQuotaDetailDataItem;
    SubItem: typeof MsAiQuotaDetailSubItem;
    Footer: typeof MsAiQuotaDetailFooter;
    FooterAction: typeof MsAiQuotaDetailFooterAction;
};
export declare const MsAiQuotaDetail: MsAiQuotaDetailComponent;
export {};
