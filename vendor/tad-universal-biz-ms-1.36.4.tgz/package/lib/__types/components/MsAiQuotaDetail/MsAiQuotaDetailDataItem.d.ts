import { default as React } from 'react';
import { MsAiQuotaDetailDataItemProps } from './MsAiQuotaDetail.types';
/**
 * MsAiQuotaDetail.DataItem（数据项）
 *
 * 图标 + 标签 + 数值，可嵌套 MsAiQuotaDetail.SubItem 作为缩进子项。
 */
export declare const MsAiQuotaDetailDataItem: React.FC<MsAiQuotaDetailDataItemProps>;
