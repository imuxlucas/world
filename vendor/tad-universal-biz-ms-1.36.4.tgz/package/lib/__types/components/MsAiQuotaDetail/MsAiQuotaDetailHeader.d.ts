import { default as React } from 'react';
import { MsAiQuotaDetailHeaderProps } from './MsAiQuotaDetail.types';
/**
 * MsAiQuotaDetail.Header（面板标题栏）
 *
 * 标题 + 副标题 + 右侧操作区（直接传入 ReactNode）。
 * 标题支持渐变色，副标题灰字展示。
 */
export declare const MsAiQuotaDetailHeader: React.FC<MsAiQuotaDetailHeaderProps>;
