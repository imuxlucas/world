import { default as React } from 'react';
export interface TriggerButtonProps {
    label: React.ReactNode;
    icon?: React.ReactNode;
    /** 右侧是否直角贴合（头像组展开时与其无缝拼接） */
    squareRight?: boolean;
    onClick?: () => void;
}
/**
 * 内部组件：左侧「图标 + 文案」触发按钮（不对外导出）。
 * 基于 MxButton 的 ghost 变体。
 */
export declare const TriggerButton: React.FC<TriggerButtonProps>;
