import { default as React } from 'react';
import { MsSubjectAvatar } from './MsSubjectLibraryButton.types';
export interface AvatarStackProps {
    subjects: MsSubjectAvatar[];
    /** 是否处于展开态（决定收起/展开与交互开关） */
    revealed: boolean;
    onSelectSubject?: (subject: MsSubjectAvatar, index: number) => void;
}
/**
 * 内部组件：右侧 docker 风格头像堆叠（不对外导出）。
 *
 * - 折叠态叠罗汉（负 margin 重叠）；hover 某头像时整组展开留出空隙（x 位移）；
 * - 被 hover 头像抬升放大并置顶，邻居按距离衰减抬升（y 位移）；
 * - x / y 均由共享弹簧引擎 useSprings 驱动，逐帧写 transform，不触发 React 渲染；
 * - 纯 UI，无业务逻辑，图片按传入 URL 原样展示。
 */
export declare const AvatarStack: React.FC<AvatarStackProps>;
