import { default as React } from 'react';
/**
 * 单个主体头像数据（纯展示，UI 不感知业务含义）
 */
export interface MsSubjectAvatar {
    /** 唯一标识，作为 React key 使用 */
    id: string;
    /** 主体名称，用于 hover tooltip 与无障碍 aria-label */
    name: string;
    /**
     * 头像地址
     *
     * 直接作为 `<img src>` 渲染；组件按 `object-fit: cover` 居中裁切，
     * 不做任何拼接图 / 位置计算等业务处理，请由调用方传入可直接展示的方图。
     */
    avatarUrl: string;
}
/**
 * 头像组展示时机
 *
 * - `always` — 头像组始终展示（常驻）
 * - `hover` — 默认收起，鼠标移入整个组件时才展开展示（默认）
 */
export type MsSubjectAvatarVisibility = 'always' | 'hover';
/**
 * 组件 MsSubjectLibraryButton (主体库按钮) 的配置项
 */
export interface MsSubjectLibraryButtonProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onSelect'> {
    /**
     * 主体头像列表
     *
     * 不传或为空数组时，仅展示左侧「主体库」按钮，不渲染右侧头像组。
     */
    subjects?: MsSubjectAvatar[];
    /**
     * 头像组展示时机
     *
     * - `always`：头像组常驻展示
     * - `hover`（默认）：默认收起，hover 组件时展开
     *
     * @default 'hover'
     */
    avatarVisibility?: MsSubjectAvatarVisibility;
    /**
     * 按钮文案
     *
     * @default '主体库'
     */
    label?: React.ReactNode;
    /**
     * 按钮左侧图标
     *
     * 不传时使用内置的默认图标。
     */
    icon?: React.ReactNode;
    /**
     * 点击「主体库」按钮回调
     */
    onOpenLibrary?: () => void;
    /**
     * 点击某个头像回调
     *
     * @param subject 被点击的主体数据
     * @param index 该主体在 `subjects` 中的索引
     */
    onSelectSubject?: (subject: MsSubjectAvatar, index: number) => void;
}
