import { default as React } from 'react';
import { MsSubjectLibraryButtonProps } from './MsSubjectLibraryButton.types';
/**
 * MsSubjectLibraryButton (主体库按钮)
 *
 * 左侧「图标 + 文案」按钮 + 右侧 docker 风格头像堆叠的组合组件。
 *
 * 纯 UI，不含任何业务逻辑：
 * - 头像数据由 `subjects` 传入；为空时仅展示按钮。
 * - 头像组展示时机由 `avatarVisibility` 控制（`always` 常驻 / `hover` 悬停展开）。
 * - 头像图片按传入 URL 原样展示（`object-fit: cover`），不做拼接图裁切等处理。
 *
 * 文档: https://tad-universal.woa.com/biz-ms/?path=/docs/组件-MsSubjectLibraryButton-主体库按钮--文档
 */
export declare const MsSubjectLibraryButton: React.ForwardRefExoticComponent<MsSubjectLibraryButtonProps & React.RefAttributes<HTMLDivElement>>;
