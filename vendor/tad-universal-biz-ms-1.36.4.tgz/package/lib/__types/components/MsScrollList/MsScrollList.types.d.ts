import { default as React } from 'react';
/**
 * MsScrollList 控制器
 *
 * 通过 `controlRef` 获取，用于命令式操作列表滚动与高亮。
 */
export interface MsScrollListControl {
    /**
     * 滚动到指定 item
     *
     * 列表项需要通过 `data-{datasetName}` 属性标记，默认 `data-item-id`
     */
    scrollToItem: (itemId: string, options?: {
        /**
         * data-* 属性名，默认 `item-id`
         */
        datasetName?: string;
    } & ScrollIntoViewOptions) => void;
    /**
     * 高亮指定 item
     *
     * 命中时由组件在目标元素上写入内部 dataset 标记（`data-ms-scroll-list-active="true"`），
     * 持续 `duration` 后移除；样式由组件内置，调用方无需关心该属性。
     */
    highlightItem: (itemId: string, options?: {
        /**
         * data-* 属性名，默认 `item-id`
         */
        datasetName?: string;
        /**
         * 高亮持续时间 (ms)，默认 1000
         */
        duration?: number;
    }) => void;
    /**
     * 滚动到顶部
     */
    scrollToTop: () => void;
    /**
     * 滚动到底部
     */
    scrollToBottom: () => void;
}
/**
 * MsScrollList (妙思滚动加载列表) 的配置项
 *
 * 滚动加载的通用布局容器：
 * - 内部负责垂直滚动、滚动方向检测、触底回调、加载更多、加载中 / 没有更多提示
 */
export interface MsScrollListProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * 到达尾部的阈值距离 (px)，默认 100
     *
     */
    loadMoreThreshold?: number;
    /**
     * 是否还有更多数据
     *
     * 配合 `onLoadMore` 使用：`hasMore = true` 时会在底部渲染 sentinel，进入视口触发 `onLoadMore`
     */
    hasMore?: boolean;
    /**
     * 是否正在加载数据
     *
     * 为 `true` 时底部显示 `loadingContent`；避免触发重复加载
     */
    isLoading?: boolean;
    /**
     * 加载更多回调
     */
    onLoadMore?: () => void;
    /**
     * 加载中的自定义内容，默认展示 TDesign Loading
     */
    loadingContent?: React.ReactNode;
    /**
     * 没有更多数据时的底部提示，默认 `没有更多内容`
     */
    endContent?: React.ReactNode;
    /**
     * 滚动事件回调（除原生 onScroll 外额外提供 top / 方向）
     */
    onScrollChange?: (e: {
        top: number;
        direction: 'up' | 'down';
    }) => void;
    /**
     * 滚动接近底部时触发（比 `onLoadMore` 更宽松，不受 `hasMore` / `isLoading` 约束）
     */
    onScrollReachEnd?: () => void;
    /**
     * 命令式控制器
     */
    controlRef?: React.RefObject<MsScrollListControl | null>;
}
