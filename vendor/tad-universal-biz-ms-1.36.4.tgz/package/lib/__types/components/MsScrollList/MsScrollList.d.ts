import { default as React } from 'react';
import { MsScrollListProps } from './MsScrollList.types';
/**
 * MsScrollList (妙思滚动加载列表)
 *
 * 滚动加载的通用布局容器，负责：
 * - 垂直滚动 + 滚动方向检测
 * - 基于 IntersectionObserver 的触底加载
 * - 命令式滚动到指定 item / 高亮 item
 *
 * 子节点请带 `data-item-id`（可通过控制器 options 自定义 datasetName）以支持滚动定位。
 */
export declare const MsScrollList: React.FC<MsScrollListProps>;
