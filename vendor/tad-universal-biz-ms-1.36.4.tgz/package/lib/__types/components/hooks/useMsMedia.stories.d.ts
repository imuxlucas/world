import { Meta, StoryFn } from '@storybook/react';
declare const meta: Meta;
export default meta;
export declare const Default: StoryFn;
export declare const Forced: StoryFn;
