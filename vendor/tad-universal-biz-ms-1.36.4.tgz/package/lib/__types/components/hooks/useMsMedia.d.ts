/**
 * 媒体类型枚举，用于区分桌面端和移动端
 */
export type MsMedia = 'desktop' | 'mobile';
export interface UseMsMediaOptions {
    /**
     * 强制指定媒体模式
     *
     * 传入后将跳过自动检测，直接使用该值
     */
    media?: MsMedia;
}
/**
 * useMsMedia (媒体类型检测)
 *
 * 根据窗口宽度自动检测当前媒体类型（桌面端 / 移动端），
 * 也支持通过 media 参数强制指定。
 *
 * 内部使用共享的 resize 监听，多个组件调用不会产生多余的事件监听器。
 *
 * ```ts
 * import { useMsMedia } from '@tencent/tad-universal-biz-ms';
 *
 * const media = useMsMedia(); // 'desktop' | 'mobile'
 * const media = useMsMedia({ media: 'mobile' }); // 强制 'mobile'
 * ```
 */
export declare function useMsMedia(options?: UseMsMediaOptions): MsMedia;
