import { default as React } from 'react';
import { MsAiInputHintProps } from './MsAiInputHint.types';
/**
 * MsAiInputHint (妙思 AI 输入框顶部提示)
 *
 * 输入框顶部的可关闭提示条：左侧图标 + 文案（可内嵌链接），右侧关闭按钮。
 * 图标、文案均为 ReactNode，由使用方自定义；显隐支持受控/非受控。
 *
 * 文案内的链接由使用方自行编写（Tailwind + CSS 变量），如：
 * `<span className="cursor-pointer font-medium text-[var(--mx-color-blue-800)]" onClick={...}>妙思资金分配</span>`
 *
 * 使用方式：
 * ```tsx
 * <MsAiInputHint icon={<GradientStar />} onClose={() => console.log('关闭')}>
 *   今日额度不足，
 *   <span className="cursor-pointer font-medium text-[var(--mx-color-blue-800)]" onClick={handleAlloc}>
 *     妙思资金分配
 *   </span>
 *   后可继续生成
 * </MsAiInputHint>
 * ```
 */
export declare const MsAiInputHint: React.FC<MsAiInputHintProps>;
