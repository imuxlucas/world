import { default as React } from 'react';
/**
 * MsAiInputHint 组件配置项
 *
 * 妙思 AI 输入框顶部的可关闭提示条：左侧图标 + 文案（可内嵌链接），右侧关闭按钮。
 * 图标与文案均为 ReactNode，完全由使用方自定义（如渐变 AI star、可点击链接等）。
 */
export interface MsAiInputHintProps {
    /**
     * 容器类名
     */
    className?: string;
    /**
     * 容器样式
     */
    style?: React.CSSProperties;
    /**
     * 左侧图标（ReactNode，完全自定义，如渐变 AI star）；不传则不显示图标
     */
    icon?: React.ReactNode;
    /**
     * 提示文案（ReactNode，可内嵌 MsAiInputHint.Link 等可点击链接）
     */
    children?: React.ReactNode;
    /**
     * 受控显隐
     */
    visible?: boolean;
    /**
     * 非受控初始显隐，默认 true
     */
    defaultVisible?: boolean;
    /**
     * 点击关闭按钮的回调（受控/非受控都会触发）
     */
    onClose?: () => void;
    /**
     * 是否显示关闭按钮，默认 true
     */
    closable?: boolean;
    /**
     * 自定义关闭图标，默认 MxIconXmark
     */
    closeIcon?: React.ReactNode;
    /**
     * 关闭按钮的原生 HTML 属性透传（如 data-* 埋点、aria-label 等）
     */
    closeButtonProps?: React.ButtonHTMLAttributes<HTMLButtonElement> & {
        [dataAttr: `data-${string}`]: unknown;
    };
}
