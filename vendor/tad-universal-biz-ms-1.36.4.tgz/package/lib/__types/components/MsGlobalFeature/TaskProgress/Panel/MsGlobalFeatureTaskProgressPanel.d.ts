import { default as React } from 'react';
import { MsGlobalFeatureTaskProgressProps } from '../MsGlobalFeatureTaskProgress.types';
/**
 * MsGlobalFeatureTaskProgressPanel 默认面板内部组件
 *
 * 当业务方未传 children 时，TaskProgress 渲染该面板：
 * - 头部：tab 切换 + 一键已读 + 「···」模块筛选
 * - 列表：按日期分组，使用 MsScrollList 支持触底加载
 * - 空态：暂无通知 + 「设置接收范围」入口（带模块筛选）
 *
 * 该组件为内部实现，不导出到包入口。业务方应使用 `MsGlobalFeatureTaskProgress`。
 */
export declare const MsGlobalFeatureTaskProgressPanel: React.FC<MsGlobalFeatureTaskProgressProps>;
