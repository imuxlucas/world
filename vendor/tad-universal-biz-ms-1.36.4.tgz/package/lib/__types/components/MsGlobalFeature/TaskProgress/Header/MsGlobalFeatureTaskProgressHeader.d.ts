import { default as React } from 'react';
import { MsGlobalFeatureTaskProgressHeaderProps } from './MsGlobalFeatureTaskProgressHeader.types';
/**
 * MsGlobalFeatureTaskProgressHeader (任务进度面板头部)
 *
 * TaskProgress 业务面板顶部通用区域：
 *
 * - 左侧：tab 切换
 * - 右侧：自定义操作（extra）
 *
 * 通常也可以通过命名空间访问：`MsGlobalFeatureTaskProgress.Header`
 */
export declare const MsGlobalFeatureTaskProgressHeader: React.FC<MsGlobalFeatureTaskProgressHeaderProps>;
