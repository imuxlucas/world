import { default as React } from 'react';
/**
 * 任务状态
 */
export type MsGlobalFeatureTaskProgressRowStatus = 'success' | 'failed' | 'generating';
/**
 * 任务进度单行（TaskRow）组件配置项
 *
 * 用于在 TaskProgress 的业务面板内展示单条任务记录
 */
export interface MsGlobalFeatureTaskProgressRowProps {
    /**
     * 任务类型标题（例如："图片生成"、"小说短剧创意"）
     */
    type: React.ReactNode;
    /**
     * 业务任务 ID（展示在类型后面）
     */
    taskId: React.ReactNode;
    /**
     * 任务状态
     */
    status: MsGlobalFeatureTaskProgressRowStatus;
    /**
     * 生成进度（仅 status="generating" 时生效，0-100）
     */
    progress?: number;
    /**
     * 任务时间，HH:mm:ss 格式字符串
     */
    time: React.ReactNode;
    /**
     * 任务封面图 URL（仅 status="success" 时生效）
     */
    cover?: string;
    /**
     * 是否未读（展示右侧红点）
     */
    unread?: boolean;
    /**
     * 自定义状态文案（覆盖默认文案：生成中 {progress}% / 生成失败 / 生成成功）
     */
    statusText?: React.ReactNode;
    /**
     * 点击整行回调
     */
    onClick?: (e: React.MouseEvent<HTMLDivElement>) => void;
    /**
     * 容器额外类名
     */
    className?: string;
    /**
     * 容器额外样式
     */
    style?: React.CSSProperties;
}
