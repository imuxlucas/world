import { default as React } from 'react';
import { PopupProps, DrawerProps } from 'tdesign-react';
import { MsGlobalFeatureNavButtonProps } from '../NavButton/MsGlobalFeatureNavButton.types';
import { MsGlobalFeatureTaskProgressRowProps } from './Row/MsGlobalFeatureTaskProgressRow.types';
import { MsGlobalFeatureTaskProgressModuleOption } from './ModuleSelect/MsGlobalFeatureTaskProgressModuleSelect.types';
/**
 * 单条任务数据（默认面板使用）
 *
 * 复用 Row 的展示字段 + 业务字段（id / date 用于分组）
 */
export interface MsGlobalFeatureTaskProgressTaskItem extends Omit<MsGlobalFeatureTaskProgressRowProps, 'onClick' | 'className' | 'style'> {
    /** 唯一 id（用于 React key） */
    id: string;
    /**
     * 日期分组 key
     *
     * 例如 `'今天'` / `'2026-04-08'`，相同 key 的任务会渲染在同一个分组下
     */
    date: string;
}
/**
 * Tab 类型（默认面板）
 */
export type MsGlobalFeatureTaskProgressTab = 'done' | 'doing';
/**
 * MsGlobalFeatureTaskProgress 组件配置项
 *
 * 任务进度入口（桌面端 icon + Popup / 移动端 icon + title + Drawer）。
 *
 * 继承自 `MsGlobalFeatureNavButtonProps`，触发按钮的 title / icon / showDot / media
 * 等参数用法与 NavButton 完全一致。
 *
 * 业务方有两种使用方式：
 * 1. **默认面板**（推荐）：传 `completedTasks` / `generatingTasks` 等数据，组件自动渲染 tab + 列表 + 空态
 * 2. **完全自定义**：传 `children`，自己实现面板内容
 */
export interface MsGlobalFeatureTaskProgressProps extends Omit<MsGlobalFeatureNavButtonProps, 'title' | 'icon' | 'children'> {
    /**
     * 完全自定义面板内容（最高优先级）
     *
     * 传入后会覆盖默认面板，业务方完全自己控制。
     *
     * - 桌面端会被放进 Popup overlay
     * - 移动端会被放进 Drawer
     */
    children?: React.ReactNode;
    /**
     * 按钮图标
     *
     * @default <MxIconAiStar />
     */
    icon?: React.ReactElement;
    /**
     * 按钮标题
     *
     * - 移动端：直接显示在 icon 旁
     * - 桌面端：作为 Tooltip 内容（hover 时展示）
     *
     * @default '任务进度'
     */
    title?: React.ReactNode;
    /**
     * 弹出面板显隐受控值
     *
     * 不传则组件内部自管理
     */
    visible?: boolean;
    /**
     * 弹出面板显隐变更回调
     */
    onVisibleChange?: (visible: boolean) => void;
    /**
     * 桌面端 Popup 触发方式
     *
     * @default 'click'
     */
    trigger?: 'click' | 'hover';
    /**
     * 桌面端 Popup 宽度
     *
     * @default 368
     */
    popupWidth?: number;
    /**
     * 桌面端 Popup 最小高度
     *
     * 用于空态时不会塌缩到很小
     *
     * @default 160
     */
    popupMinHeight?: number;
    /**
     * 桌面端 Popup 最大高度
     *
     * 内容超出后内部列表自动滚动
     *
     * @default 480
     */
    popupMaxHeight?: number;
    /**
     * 桌面端 Popup 配置（透传给 TDesign Popup，会与组件默认值合并）
     */
    popupProps?: Omit<PopupProps, 'content' | 'children' | 'visible' | 'onVisibleChange'>;
    /**
     * 移动端 Drawer 配置（透传给 TDesign Drawer）
     */
    drawerProps?: Omit<DrawerProps, 'children' | 'visible' | 'onClose'>;
    /**
     * 已完成任务列表（含成功 / 失败）
     */
    completedTasks?: MsGlobalFeatureTaskProgressTaskItem[];
    /**
     * 生成中任务列表
     */
    generatingTasks?: MsGlobalFeatureTaskProgressTaskItem[];
    /**
     * 默认面板默认展示的 tab
     *
     * @default 'done'
     */
    defaultTab?: MsGlobalFeatureTaskProgressTab;
    /**
     * 默认面板当前激活的 tab（受控）
     */
    activeTab?: MsGlobalFeatureTaskProgressTab;
    /**
     * tab 切换回调
     */
    onTabChange?: (tab: MsGlobalFeatureTaskProgressTab) => void;
    /**
     * 点击「一键已读」回调
     *
     * 不传则不展示「一键已读」按钮
     */
    onReadAll?: () => void;
    /**
     * 一键已读按钮文案
     *
     * @default '一键已读'
     */
    readAllText?: React.ReactNode;
    /**
     * 点击单条任务回调
     */
    onClickItem?: (item: MsGlobalFeatureTaskProgressTaskItem) => void;
    /**
     * 已完成 tab：是否还有更多
     */
    completedHasMore?: boolean;
    /**
     * 已完成 tab：是否正在加载
     */
    completedLoading?: boolean;
    /**
     * 已完成 tab：触底加载更多
     */
    onLoadMoreCompleted?: () => void;
    /**
     * 生成中 tab：是否还有更多
     */
    generatingHasMore?: boolean;
    /**
     * 生成中 tab：是否正在加载
     */
    generatingLoading?: boolean;
    /**
     * 生成中 tab：触底加载更多
     */
    onLoadMoreGenerating?: () => void;
    /**
     * 是否展示头部右侧「···」更多按钮（接收范围模块筛选入口）
     *
     * 当传入 `modules` 时默认 `true`，否则默认 `false`
     */
    showMore?: boolean;
    /**
     * 接收范围/通知模块选项列表（默认面板「···」 与 空态「设置接收范围」共用）
     *
     * 不传则不展示模块筛选 UI
     */
    modules?: MsGlobalFeatureTaskProgressModuleOption[];
    /**
     * 默认选中的模块 value 列表（非受控）
     *
     * 不传则默认全选
     */
    defaultSelectedModules?: string[];
    /**
     * 当前选中的模块 value 列表（受控）
     */
    selectedModules?: string[];
    /**
     * 选中模块变化回调
     */
    onSelectedModulesChange?: (values: string[]) => void;
    /**
     * 空态主文案
     *
     * @default '暂无通知'
     */
    emptyText?: React.ReactNode;
    /**
     * 空态副文案（可点击，配合 modules 使用展示模块筛选下拉）
     *
     * @default '设置任务进度接收范围'
     */
    emptyActionText?: React.ReactNode;
    /**
     * 没有更多数据时底部提示
     *
     * @default '已经到底啦'
     */
    endText?: React.ReactNode;
}
