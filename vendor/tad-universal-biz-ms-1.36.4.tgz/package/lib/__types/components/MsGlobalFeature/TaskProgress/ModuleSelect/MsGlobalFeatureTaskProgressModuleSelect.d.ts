import { default as React } from 'react';
import { MsGlobalFeatureTaskProgressModuleSelectProps } from './MsGlobalFeatureTaskProgressModuleSelect.types';
/**
 * MsGlobalFeatureTaskProgressModuleSelect (任务进度模块多选)
 *
 * 任务进度面板里"接收范围/接收通知的模块"多选下拉的内容部分。
 *
 * - 顶部可选标题
 * - 顶部"全选"行（自动同步其余选项）
 * - 多个 Checkbox 列表项
 *
 * 通常作为 Popup overlay 的内容使用，由业务方自行包裹 Popup。
 *
 * 也可以通过命名空间访问：`MsGlobalFeatureTaskProgress.ModuleSelect`
 */
export declare const MsGlobalFeatureTaskProgressModuleSelect: React.FC<MsGlobalFeatureTaskProgressModuleSelectProps>;
