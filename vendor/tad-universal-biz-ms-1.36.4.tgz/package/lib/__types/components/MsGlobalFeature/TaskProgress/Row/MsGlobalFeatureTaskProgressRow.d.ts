import { default as React } from 'react';
import { MsGlobalFeatureTaskProgressRowProps } from './MsGlobalFeatureTaskProgressRow.types';
/**
 * MsGlobalFeatureTaskProgressRow (任务进度单行)
 *
 * TaskProgress 业务面板内的单条任务记录展示：
 *
 * - 左侧：封面图（成功）/ 感叹号（失败）/ 渐变占位（生成中）
 * - 中间：类型 + 任务 ID + 状态文案 + 时间
 * - 右侧：未读红点（可选）
 *
 * 通常也可以通过命名空间访问：`MsGlobalFeatureTaskProgress.Row`
 */
export declare const MsGlobalFeatureTaskProgressRow: React.FC<MsGlobalFeatureTaskProgressRowProps>;
