import { default as React } from 'react';
/**
 * 模块选项
 */
export interface MsGlobalFeatureTaskProgressModuleOption {
    /** 选项展示文本 */
    label: React.ReactNode;
    /** 选项值（唯一） */
    value: string;
}
/**
 * MsGlobalFeatureTaskProgressModuleSelect Props
 *
 * 任务进度的"接收范围 / 接收模块"多选面板：
 * - 顶部可选标题（如"请选择接收通知的模块"、"设置任务进度接收范围"）
 * - 顶部"全选" 复选框（自动联动其余选项）
 * - 列表项：每行一个 Checkbox
 *
 * 通常作为 Popup overlay 的内容使用。
 */
export interface MsGlobalFeatureTaskProgressModuleSelectProps {
    /**
     * 顶部标题（不传则不渲染）
     */
    title?: React.ReactNode;
    /**
     * 模块列表
     */
    modules: MsGlobalFeatureTaskProgressModuleOption[];
    /**
     * 当前选中的 value 列表（受控）
     */
    value: string[];
    /**
     * 选中变化回调
     */
    onChange: (value: string[]) => void;
    /**
     * 是否展示"全选"行
     *
     * @default true
     */
    showSelectAll?: boolean;
    /**
     * "全选"行的文案
     *
     * @default '全选'
     */
    selectAllLabel?: React.ReactNode;
    /** 自定义类名 */
    className?: string;
    /** 自定义内联样式 */
    style?: React.CSSProperties;
}
