import { default as React } from 'react';
/**
 * 单个 Tab 配置项
 */
export interface MsGlobalFeatureTaskProgressHeaderTab {
    /** Tab 唯一标识 */
    key: string;
    /** Tab 展示文字 */
    label: React.ReactNode;
}
/**
 * MsGlobalFeatureTaskProgressHeader Props
 *
 * 任务进度面板顶部的通用头部：
 * - 左侧：tab 切换（已完成 / 生成中 等）
 * - 右侧：自定义操作区（如"一键已读"、"更多"）
 */
export interface MsGlobalFeatureTaskProgressHeaderProps {
    /**
     * Tab 列表
     *
     * 为空或传 `false` 时不渲染左侧 tab 区域
     */
    tabs?: MsGlobalFeatureTaskProgressHeaderTab[];
    /**
     * 当前激活的 Tab key（受控）
     */
    activeTab?: string;
    /**
     * Tab 切换回调
     */
    onTabChange?: (key: string) => void;
    /**
     * 右侧操作区自定义内容
     *
     * 如"一键已读"按钮、"更多"图标等
     */
    extra?: React.ReactNode;
    /** 自定义类名 */
    className?: string;
    /** 自定义内联样式 */
    style?: React.CSSProperties;
}
