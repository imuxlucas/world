import { default as React } from 'react';
import { MsGlobalFeatureTaskProgressProps } from './MsGlobalFeatureTaskProgress.types';
import { MsGlobalFeatureTaskProgressRow } from './Row/MsGlobalFeatureTaskProgressRow';
import { MsGlobalFeatureTaskProgressHeader } from './Header/MsGlobalFeatureTaskProgressHeader';
import { MsGlobalFeatureTaskProgressModuleSelect } from './ModuleSelect/MsGlobalFeatureTaskProgressModuleSelect';
/**
 * MsGlobalFeatureTaskProgress (妙思全局任务进度入口)
 *
 * 任务进度 / 通知中心 等"icon + 红点 + 弹出面板"类全局功能入口的通用组件。
 *
 * - 桌面端：icon 按钮（默认 ai-star，带红点），点击弹出 Popup（默认 368×480）
 * - 移动端：icon + title 文本，点击弹出 Drawer 抽屉（从底部滑出）
 *
 * 触发按钮复用 `MsGlobalFeatureNavButton`，保持全局功能入口的交互和样式一致。
 * 内部使用 `useMsMedia` 自动判断媒体类型。
 *
 * 业务方有两种使用方式：
 * 1. **默认面板（推荐）**：传入 `completedTasks` / `generatingTasks` / `modules` 等数据，
 *    组件自动渲染 tab + 列表（MsScrollList，支持分页加载）+ 空态 + 模块筛选下拉。
 * 2. **完全自定义**：传入 `children` 覆盖默认面板。
 *
 * 同时作为命名空间提供子组件：
 * - `MsGlobalFeatureTaskProgress.Row` — 任务进度单行
 * - `MsGlobalFeatureTaskProgress.Header` — 任务进度面板头部
 * - `MsGlobalFeatureTaskProgress.ModuleSelect` — 接收范围/模块多选下拉
 */
export declare const MsGlobalFeatureTaskProgress: React.FC<MsGlobalFeatureTaskProgressProps> & {
    Row: typeof MsGlobalFeatureTaskProgressRow;
    Header: typeof MsGlobalFeatureTaskProgressHeader;
    ModuleSelect: typeof MsGlobalFeatureTaskProgressModuleSelect;
};
