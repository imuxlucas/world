import { default as React } from 'react';
import { MsGlobalFeatureNotificationProps } from './MsGlobalFeatureNotification.types';
/**
 * MsGlobalFeatureNotification (妙思全局通知组件)
 *
 * 桌面端：NavButton 触发器 + Popup 气泡面板
 * 移动端：NavButton 触发器（横排 icon + 文案）+ 底部 Drawer
 */
export declare const MsGlobalFeatureNotification: React.FC<MsGlobalFeatureNotificationProps>;
