import { default as React } from 'react';
import { PopupProps } from 'tdesign-react';
import { MsGlobalFeatureNavButtonProps } from '../NavButton/MsGlobalFeatureNavButton.types';
import { MsScrollListProps } from '../../MsScrollList/MsScrollList.types';
/**
 * 单条消息
 */
export interface MsGlobalFeatureNotificationItem {
    /**
     * 消息 ID
     */
    id: string | number;
    /**
     * 消息标题
     */
    title: React.ReactNode;
    /**
     * 消息描述
     */
    description?: React.ReactNode;
    /**
     * 是否未读（用于显示右侧红点）
     */
    isUnread?: boolean;
}
/**
 * 按日期分组后的消息
 */
export interface MsGlobalFeatureNotificationGroup {
    /**
     * 分组标题，例如「今天」「昨天」「2026-04-06」等
     */
    key: React.ReactNode;
    /**
     * 该分组下的消息列表
     */
    items: MsGlobalFeatureNotificationItem[];
}
/**
 * MsGlobalFeatureNotification 组件配置项
 *
 * 全局通知组件，包含触发按钮（NavButton）+ 通知面板
 * - 桌面端：Popup 气泡面板
 * - 移动端：底部 Drawer
 *
 */
export interface MsGlobalFeatureNotificationProps extends Omit<MsGlobalFeatureNavButtonProps, 'className' | 'style' | 'title' | 'icon' | 'data' | 'badge'> {
    /**
     * 组件类名（落在最外层容器上）
     */
    className?: string;
    /**
     * 组件样式（落在最外层容器上）
     */
    style?: React.CSSProperties;
    /**
     * 触发按钮标题，默认 "通知中心"
     */
    title?: React.ReactNode;
    /**
     * 触发按钮图标，默认 MxIconBell
     */
    icon?: React.ReactElement;
    /**
     * 面板是否展开（受控）
     */
    visible?: boolean;
    /**
     * 面板开关回调
     */
    onVisibleChange?: (visible: boolean) => void;
    /**
     * 已分好组的消息数据
     */
    data?: MsGlobalFeatureNotificationGroup[];
    /**
     * 未读消息数量（由外层控制，不再根据 `data` 自动推导）
     *
     * - `> 0`：触发器展示数字徽标（>99 显示 `99+`）
     * - `0` / `undefined`：不展示徽标
     *
     * 注意：列表中单条消息的小红点仍由 `item.isUnread` 控制，与本字段相互独立。
     */
    unreadCount?: number;
    /**
     * 「一键已读」是否置灰不可点
     *
     * - 显式传入 `true` / `false`：完全由外层控制
     * - 未传：fallback 到 `unreadCount > 0`（即没有未读时自动置灰）
     */
    readAllDisabled?: boolean;
    /**
     * 「一键已读」点击回调
     */
    onReadAll?: () => void;
    /**
     * 「一键已读」文案，默认「一键已读」
     */
    readAllText?: React.ReactNode;
    /**
     * 面板标题文案，默认「通知中心」
     */
    panelTitle?: React.ReactNode;
    /**
     * 单条消息点击回调
     */
    onMessageClick?: (item: MsGlobalFeatureNotificationItem, group: MsGlobalFeatureNotificationGroup, e: React.MouseEvent | React.KeyboardEvent) => void;
    /**
     * 空态内容，默认「暂无通知」
     */
    emptyContent?: React.ReactNode;
    /**
     * 列表（MsScrollList）配置透传
     *
     * 可用于配置 `hasMore` / `isLoading` / `onLoadMore` / `loadingContent` / `endContent`
     * / `onScroll` / `onScrollChange` / `onScrollReachBottom` / `bottomThreshold`
     * / `controlRef` 等；内部默认使用 `gap: 0`、`bottomPadding: 0`，如需覆盖可直接通过该对象传入。
     * 内容宽度通过 CSS 变量 `--ms-scroll-list-content-width` 配置（默认 `100%`）。
     */
    scrollListProps?: Partial<MsScrollListProps>;
    /**
     * 桌面端下拉面板（Popup）配置
     */
    dropdownProps?: Partial<PopupProps>;
    /**
     * 面板自定义类名
     */
    panelClassName?: string;
}
