/**
 * MsGlobalFeature (妙思全局功能组件)
 *
 * 命名空间，用于在全局区域（如导航等）展示的功能组件 UI，
 * 如用户登录态、全局通知提醒入口等。
 *
 * 使用方式：
 * ```tsx
 * import { MsGlobalFeature } from '@tencent/tad-universal-biz-ms';
 * <MsGlobalFeature.User isLoggedIn userInfo={...} />
 * ```
 *
 * 也可以单独导入：
 * ```tsx
 * import { MsGlobalFeatureUser } from '@tencent/tad-universal-biz-ms';
 * <MsGlobalFeatureUser isLoggedIn userInfo={...} />
 * ```
 */
export declare const MsGlobalFeature: {
    User: import('react').FC<import('.').MsGlobalFeatureUserProps> & {
        InfoBlock: typeof import('.').MsGlobalFeatureUserInfoBlock;
        InfoBlockGroup: typeof import('.').MsGlobalFeatureUserInfoBlockGroup;
    };
    NavButton: import('react').FC<import('.').MsGlobalFeatureNavButtonProps>;
    Notification: import('react').FC<import('.').MsGlobalFeatureNotificationProps>;
    TaskProgress: import('react').FC<import('.').MsGlobalFeatureTaskProgressProps> & {
        Row: typeof import('.').MsGlobalFeatureTaskProgressRow;
        Header: typeof import('.').MsGlobalFeatureTaskProgressHeader;
        ModuleSelect: typeof import('.').MsGlobalFeatureTaskProgressModuleSelect;
    };
    Feedback: import('react').FC<import('.').MsGlobalFeatureFeedbackProps>;
};
