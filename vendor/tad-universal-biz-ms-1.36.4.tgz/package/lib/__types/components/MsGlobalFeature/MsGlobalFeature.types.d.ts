import { default as React } from 'react';
/**
 * 组件 MsGlobalFeature (妙思全局功能组件) 的配置项
 *
 * MsGlobalFeature 本身是一个命名空间，不是组件。
 * 通过 MsGlobalFeature.User 等方式使用子组件。
 */
export type MsGlobalFeatureNamespace = {
    User: React.FC;
    NavButton: React.FC;
    Notification: React.FC;
};
