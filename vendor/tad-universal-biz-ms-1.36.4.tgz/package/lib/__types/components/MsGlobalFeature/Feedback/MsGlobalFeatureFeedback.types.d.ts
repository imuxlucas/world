import { default as React } from 'react';
import { MsGlobalFeatureNavButtonProps } from '../NavButton/MsGlobalFeatureNavButton.types';
import { MsMedia } from '../../hooks';
/** 单个 Tab 配置 */
export interface MsGlobalFeatureFeedbackTab {
    /** Tab 唯一标识 */
    key: string;
    /** Tab 标签文案 */
    label: React.ReactNode;
    /** iframe 地址 */
    src: string;
    /** iframe title（无障碍） */
    iframeTitle?: string;
    /** 面板宽度（该 Tab 激活时使用），默认 520px */
    panelWidth?: number | string;
    /** 面板背景色（该 Tab 激活时使用） */
    panelBackground?: string;
    /** iframe 偏移（用于隐藏 iframe 内部自带的 header 等区域） */
    iframeOffset?: {
        top?: number;
        left?: number;
    };
    /** 每次切到该 Tab 时是否强制重新加载 iframe，默认 false */
    reloadOnActivate?: boolean;
}
/** MsGlobalFeatureFeedback 组件配置项 */
export interface MsGlobalFeatureFeedbackProps extends MsGlobalFeatureNavButtonProps {
    /** 响应式断点 */
    media?: MsMedia;
    /** 受控：面板是否打开 */
    visible?: boolean;
    /** 面板开关变化回调 */
    onVisibleChange?: (visible: boolean) => void;
    /** Tab 配置列表（至少 1 项） */
    tabs: MsGlobalFeatureFeedbackTab[];
    /** 受控：当前激活的 Tab key */
    activeTab?: string;
    /** 默认激活的 Tab key（非受控时使用），默认取 tabs[0].key */
    defaultActiveTab?: string;
    /** Tab 切换回调 */
    onTabChange?: (tabKey: string) => void;
    /** 面板 className */
    panelClassName?: string;
    /** 是否显示蒙层，默认 true */
    overlay?: boolean;
    /** 蒙层 className */
    overlayClassName?: string;
    /** 点击蒙层是否关闭面板，默认 false */
    closeOnOverlayClick?: boolean;
    /** 自定义 loading 节点（传 null 禁用 loading） */
    loadingContent?: React.ReactNode;
}
