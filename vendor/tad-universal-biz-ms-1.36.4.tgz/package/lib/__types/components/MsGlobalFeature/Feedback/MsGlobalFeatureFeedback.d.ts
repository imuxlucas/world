import { default as React } from 'react';
import { MsGlobalFeatureFeedbackProps } from './MsGlobalFeatureFeedback.types';
/**
 * MsGlobalFeatureFeedback（妙思全局反馈侧拉面板）
 *
 * NavButton 触发器 + 右侧抽屉面板，面板内为 Tab 切换 + iframe 内容区。
 * 纯 UI 组件，不包含业务逻辑。
 */
export declare const MsGlobalFeatureFeedback: React.FC<MsGlobalFeatureFeedbackProps>;
