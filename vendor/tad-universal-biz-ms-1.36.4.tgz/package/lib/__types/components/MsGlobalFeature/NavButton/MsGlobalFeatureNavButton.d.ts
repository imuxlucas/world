import { default as React } from 'react';
import { MsGlobalFeatureNavButtonProps } from './MsGlobalFeatureNavButton.types';
/**
 * MsGlobalFeatureNavButton (妙思全局导航按钮)
 *
 * 桌面端：仅展示 icon，hover 显示 Tooltip
 * 移动端：展示 icon + title
 */
export declare const MsGlobalFeatureNavButton: React.FC<MsGlobalFeatureNavButtonProps>;
