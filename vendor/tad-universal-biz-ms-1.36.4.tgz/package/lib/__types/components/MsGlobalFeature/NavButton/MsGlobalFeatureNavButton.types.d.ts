import { default as React } from 'react';
import { ButtonProps, TooltipProps } from 'tdesign-react';
import { MsMedia } from '../../hooks';
/**
 * MsGlobalFeatureNavButton 组件配置项
 *
 * 导航按钮，桌面端仅展示 icon（hover 显示 Tooltip），移动端展示 icon + title
 */
export interface MsGlobalFeatureNavButtonProps extends Omit<ButtonProps, 'children' | 'title'> {
    /**
     * 按钮标题
     *
     * 桌面端作为 Tooltip 内容，移动端直接显示在 icon 旁
     */
    title: React.ReactNode;
    /**
     * 按钮图标
     */
    icon: React.ReactElement;
    /**
     * 强制指定媒体模式
     *
     * 不传则根据窗口宽度自动检测
     */
    media?: MsMedia;
    /**
     * Tooltip 配置（仅桌面端生效）
     *
     * 传入 TDesign TooltipProps 覆盖默认配置
     */
    tooltipProps?: Omit<TooltipProps, 'content' | 'children'>;
    /**
     * 右上角徽标
     *
     * - `true`：仅显示红点（无数字）
     * - `number`：显示具体数字（>99 时显示 `99+`，<=0 视为不显示）
     * - `false` / 不传：不显示徽标
     *
     * 通常用于「未读消息」「任务进度」等场景
     */
    badge?: boolean | number;
}
