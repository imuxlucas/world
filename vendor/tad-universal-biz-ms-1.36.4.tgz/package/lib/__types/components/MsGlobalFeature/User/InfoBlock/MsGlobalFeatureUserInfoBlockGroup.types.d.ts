import { default as React } from 'react';
/**
 * MsGlobalFeatureUserInfoBlockGroup 组件配置项
 *
 * 信息模块的「互斥手风琴」容器：始终保留且仅保留一个子项展开。
 * 默认 hover 切换——hover 到某项即展开该项，离开不收起，hover 另一项时收起上一项。
 */
export interface MsGlobalFeatureUserInfoBlockGroupProps {
    /**
     * 容器类名
     */
    className?: string;
    /**
     * 容器样式
     */
    style?: React.CSSProperties;
    /**
     * 受控的当前展开项 value
     */
    value?: string | number;
    /**
     * 非受控初始展开项 value；不传时默认展开第一个子项（保证始终有一个展开）
     */
    defaultValue?: string | number;
    /**
     * 当前展开项变化回调
     */
    onChange?: (value: string | number) => void;
    /**
     * 切换展开的触发方式，默认 'hover'
     *
     * - `'hover'`：hover 到某项即展开（离开不收起，互斥，始终保留一个展开）
     * - `'click'`：点击标题行切换展开项
     */
    trigger?: 'hover' | 'click';
    /**
     * 子项（一组 MsGlobalFeatureUser.InfoBlock，需各自设置 value）
     */
    children?: React.ReactNode;
}
