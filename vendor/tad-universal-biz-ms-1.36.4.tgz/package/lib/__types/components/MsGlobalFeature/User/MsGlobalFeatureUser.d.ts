import { default as React } from 'react';
import { MsGlobalFeatureUserProps } from './MsGlobalFeatureUser.types';
import { MsGlobalFeatureUserInfoBlock } from './InfoBlock/MsGlobalFeatureUserInfoBlock';
import { MsGlobalFeatureUserInfoBlockGroup } from './InfoBlock/MsGlobalFeatureUserInfoBlockGroup';
/**
 * MsGlobalFeatureUser (妙思全局用户状态组件)
 *
 * 已登录态：桌面端 - 头像 + hover 下拉面板；移动端 - 小头像 + 用户名，点击弹出底部 Drawer
 * 未登录态：桌面端 - 登录按钮；移动端 - 全宽登录按钮
 */
export declare const MsGlobalFeatureUser: React.FC<MsGlobalFeatureUserProps> & {
    InfoBlock: typeof MsGlobalFeatureUserInfoBlock;
    InfoBlockGroup: typeof MsGlobalFeatureUserInfoBlockGroup;
};
