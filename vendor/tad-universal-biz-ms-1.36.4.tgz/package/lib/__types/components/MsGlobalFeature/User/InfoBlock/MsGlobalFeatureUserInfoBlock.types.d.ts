import { default as React } from 'react';
/**
 * InfoBlock 配置式内容项：标题 + 数值，均支持 ReactNode
 */
export interface MsGlobalFeatureUserInfoBlockItem {
    /**
     * 上方标题，支持 ReactNode
     */
    label?: React.ReactNode;
    /**
     * 下方数值，支持 ReactNode
     */
    value?: React.ReactNode;
}
/**
 * MsGlobalFeatureUserInfoBlock 组件配置项
 *
 * 用户信息弹框内的「信息模块」卡片：默认仅显示标题行，hover 展开显示详情内容。
 * 标题、操作文案、详情内容均支持传入 ReactNode 自定义。
 */
export interface MsGlobalFeatureUserInfoBlockProps {
    /**
     * 卡片类名
     */
    className?: string;
    /**
     * 卡片样式
     */
    style?: React.CSSProperties;
    /**
     * 标题（标题行左侧），支持 ReactNode
     */
    title?: React.ReactNode;
    /**
     * 标题行右侧操作区文案（如「配置」「查看详情」），支持 ReactNode
     */
    action?: React.ReactNode;
    /**
     * 是否显示操作区右侧箭头，默认 true
     */
    showArrow?: boolean;
    /**
     * 受控展开状态。
     *
     * - 不传（且不在 InfoBlockGroup 中）：使用默认的纯 CSS hover 展开逻辑
     * - 传入 boolean：受控，由外部控制展开/收起（同时禁用 hover 自动展开）
     *
     * 显式传入时优先级高于 InfoBlockGroup 的控制。
     */
    expanded?: boolean;
    /**
     * 在 InfoBlockGroup 中的唯一标识。
     *
     * 置于 Group 内时用于互斥手风琴：Group 通过该值判断/切换当前展开项。
     * 不在 Group 中时此值无意义。
     */
    value?: string | number;
    /**
     * 展开内容（hover 卡片时展示），支持 ReactNode。
     *
     * 设置后将忽略 `items` 配置（children 优先）。
     */
    children?: React.ReactNode;
    /**
     * 配置式展开内容：一组「标题 + 数值」，数量不限（1 个、2 个……）。
     *
     * 多项横向并排展示。若同时设置了 `children`，则忽略此配置。
     */
    items?: MsGlobalFeatureUserInfoBlockItem[];
    /**
     * 标题行（整行可点击元素）的原生 HTML 属性透传。
     *
     * 用于绑定 onClick、data-* 埋点、aria-* 等。组件已内置 role="button"、
     * tabIndex={0} 及 Enter/Space 键盘触发，可被此处传入的属性覆盖。
     *
     * 额外允许任意 `data-*` 属性（React.HTMLAttributes 在对象字面量场景下默认不含
     * data-* 索引签名），以满足埋点等自定义属性需求。
     */
    rowProps?: React.HTMLAttributes<HTMLDivElement> & {
        [dataAttr: `data-${string}`]: unknown;
    };
}
