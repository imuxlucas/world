import { default as React } from 'react';
import { MsGlobalFeatureUserInfoBlockGroupProps } from './MsGlobalFeatureUserInfoBlockGroup.types';
/**
 * InfoBlockGroup 向子 InfoBlock 下发的上下文
 */
export interface MsGlobalFeatureUserInfoBlockGroupContextValue {
    /** 当前展开项的 value */
    activeValue: string | number | undefined;
    /** 切换展开项 */
    setActiveValue: (value: string | number) => void;
    /** 触发方式 */
    trigger: 'hover' | 'click';
}
export declare const MsGlobalFeatureUserInfoBlockGroupContext: React.Context<MsGlobalFeatureUserInfoBlockGroupContextValue | null>;
/**
 * MsGlobalFeatureUserInfoBlockGroup (信息模块互斥手风琴容器)
 *
 * 包裹一组 InfoBlock，始终保留且仅保留一个展开。默认 hover 切换：
 * hover 到某项展开该项、离开不收起、hover 另一项时收起上一项。
 *
 * 使用方式：
 * ```tsx
 * <MsGlobalFeatureUser.InfoBlockGroup>
 *   <MsGlobalFeatureUser.InfoBlock value="bill" title="账单" action="查看详情">...</MsGlobalFeatureUser.InfoBlock>
 *   <MsGlobalFeatureUser.InfoBlock value="rule" title="预审规则" action="配置">...</MsGlobalFeatureUser.InfoBlock>
 * </MsGlobalFeatureUser.InfoBlockGroup>
 * ```
 */
export declare const MsGlobalFeatureUserInfoBlockGroup: React.FC<MsGlobalFeatureUserInfoBlockGroupProps>;
