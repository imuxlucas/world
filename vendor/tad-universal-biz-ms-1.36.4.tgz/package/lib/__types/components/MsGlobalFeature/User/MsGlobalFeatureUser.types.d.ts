import { default as React } from 'react';
import { RxPopoverRootProps, RxPopoverContentProps, MxButtonProps } from '@tencent/tad-universal-biz-mx';
import { MsMedia } from '../../hooks';
/**
 * @deprecated 使用 MsMedia 替代
 */
export type MsGlobalFeatureUserMedia = MsMedia;
/**
 * 用户信息数据
 */
export interface MsGlobalFeatureUserInfo {
    /**
     * 用户名
     */
    name?: string;
    /**
     * 用户 ID
     */
    userId?: string;
    /**
     * 头像 URL
     */
    avatarUrl?: string;
}
/**
 * MsGlobalFeatureUser 组件配置项
 *
 * 全局用户状态组件，包含登录态（头像 + 下拉菜单）和未登录态（登录按钮）
 */
export interface MsGlobalFeatureUserProps {
    /**
     * 组件类名
     */
    className?: string;
    /**
     * 组件样式
     */
    style?: React.CSSProperties;
    /**
     * 强制指定媒体模式
     *
     * 不传则根据窗口宽度自动检测
     */
    media?: MsMedia;
    /**
     * 是否已登录
     */
    isLoggedIn?: boolean;
    /**
     * 用户信息（已登录时使用）
     */
    userInfo?: MsGlobalFeatureUserInfo;
    /**
     * 登录按钮文案，默认 "登录"
     */
    loginText?: string;
    /**
     * 登录按钮属性
     *
     * 支持传入 MxButton 的 MxButtonProps 对象，或基于 media 返回 MxButtonProps 的函数
     */
    loginButtonProps?: Omit<MxButtonProps, 'onClick'> | ((props: {
        media: MsGlobalFeatureUserMedia;
    }) => Omit<MxButtonProps, 'onClick'>);
    /**
     * 点击登录按钮回调
     */
    onLogin?: () => void;
    /**
     * 点击退出登录回调
     */
    onLogout?: () => void;
    /**
     * 退出登录按钮属性
     *
     * 支持传入 MxButton 的 MxButtonProps 对象，或基于 media 返回 MxButtonProps 的函数
     */
    logoutButtonProps?: Omit<MxButtonProps, 'onClick'> | ((props: {
        media: MsGlobalFeatureUserMedia;
    }) => Omit<MxButtonProps, 'onClick'>);
    /**
     * 自定义内容区
     *
     * 渲染在用户信息和退出登录按钮之间（桌面端在 Popup 中，移动端在 Drawer 中）
     */
    content?: React.ReactNode;
    /**
     * 桌面端下拉面板（RxPopover）配置
     *
     * 透传给 RxPopover，可用于控制触发方式、延迟（Root）以及弹出方向、对齐、偏移、类名（Content）。
     * 默认：hover 触发、bottom/end 弹出，无尖角。
     */
    dropdownProps?: Partial<RxPopoverRootProps & RxPopoverContentProps>;
}
