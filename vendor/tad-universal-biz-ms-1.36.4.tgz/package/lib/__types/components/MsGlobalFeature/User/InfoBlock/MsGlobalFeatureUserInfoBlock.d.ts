import { default as React } from 'react';
import { MsGlobalFeatureUserInfoBlockProps } from './MsGlobalFeatureUserInfoBlock.types';
/**
 * MsGlobalFeatureUserInfoBlock (用户信息模块卡片)
 *
 * 用户信息弹框内的信息模块：默认仅显示标题行，hover 卡片时向下平滑展开详情内容。
 * 标题、操作文案、详情内容均支持 ReactNode；标题整行可点击，并可透传原生属性做埋点等。
 *
 * 使用方式：
 * ```tsx
 * <MsGlobalFeatureUser.InfoBlock
 *   title="预审规则"
 *   action="配置"
 *   rowProps={{ onClick: handleClick, 'data-track': 'user-rule' }}
 * >
 *   <div>展开后的自定义内容</div>
 * </MsGlobalFeatureUser.InfoBlock>
 * ```
 */
export declare const MsGlobalFeatureUserInfoBlock: React.FC<MsGlobalFeatureUserInfoBlockProps>;
