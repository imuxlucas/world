import { MsAccountSelectItemProps } from './MsAccountSelect.types';
/**
 * `<MsAccountSelectItem>` — 妙思账户选项
 *
 * 必须作为 `<MsAccountSelect>` 的子节点使用。
 * 通过原生 DOM 焦点驱动键盘导航（`tabIndex=-1`，由父组件 `.focus()` 控制）。
 */
export declare const MsAccountSelectItem: import('react').ForwardRefExoticComponent<MsAccountSelectItemProps & import('react').RefAttributes<HTMLDivElement>>;
