import { default as React } from 'react';
import { RxPopoverRootProps, RxPopoverTriggerProps, RxPopoverContentProps, RxInputProps } from '@tencent/tad-universal-biz-mx';
import { MsScrollListProps } from '../MsScrollList/MsScrollList.types';
/** 账户选项数据 */
export interface MsAccountSelectOption {
    /** 唯一标识 */
    key: string;
    /** 账户名 */
    label: React.ReactNode;
    /** 副标题（如 "ID"） */
    desc?: React.ReactNode;
    /** 右侧 tag；有 tag 表示当前默认账户，不显示 action */
    tag?: React.ReactNode;
    /** 是否禁用 */
    disabled?: boolean;
    /** 业务自定义数据 */
    meta?: Record<string, unknown>;
    /** hover 时右侧动作按钮内容 */
    actionContent?: React.ReactNode;
    /** 动作按钮点击回调 */
    onAction?: (option: MsAccountSelectOption, e: React.MouseEvent<HTMLButtonElement>) => void;
}
/** MsAccountSelectItem — 账户选项 */
export interface MsAccountSelectItemProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onSelect'> {
    /** 选项唯一值 */
    value: string;
    /** 账户名（作为 Trigger 回显内容） */
    label: React.ReactNode;
    /** 副标题（如 "ID"） */
    desc?: React.ReactNode;
    /** 右侧 tag；有 tag 表示当前默认账户，不显示 action */
    tag?: React.ReactNode;
    /** 是否禁用 */
    disabled?: boolean;
    /** hover 时右侧动作按钮内容 */
    actionContent?: React.ReactNode;
    /** 动作按钮点击回调（已自动阻止冒泡，不会触发选中） */
    onAction?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}
/** MsAccountSelect props，透传 RxPopover.Root 全部属性 */
export interface MsAccountSelectProps extends RxPopoverRootProps {
    /** 触发器类名 */
    className?: string;
    /** 触发器内联样式 */
    style?: React.CSSProperties;
    /** 占位文案，默认 "请选择账户" */
    placeholder?: React.ReactNode;
    /** 列表为空时展示的内容，默认 "暂无账户" */
    emptyContent?: React.ReactNode;
    /** 当前选中 value（受控） */
    value?: string;
    /** 选中变化回调 */
    onValueChange?: (value: string) => void;
    /**
     * 选中项 label 的兜底值。
     *
     * 无限滚动 / 异步分页场景下，当前 `value` 对应的选项可能还在未加载的分页里，列表中
     * 找不到对应 Item、trigger 无法回显其 label。此时由调用方把已知的 label 一并传入兜底：
     * **列表里加载到了用加载的 label，没加载到则用本 `fallbackLabel`**。
     */
    fallbackLabel?: React.ReactNode;
    /** 是否显示搜索框，默认 true */
    showSearch?: boolean;
    /** 搜索框 placeholder，默认 "搜索账户名 / ID" */
    searchPlaceholder?: string;
    /** 搜索关键字（受控），组件不做过滤，由业务侧自行过滤 children */
    searchValue?: string;
    /** 搜索值变化回调 */
    onSearchChange?: (value: string) => void;
    /** 透传 RxInput props；value/onChange/placeholder 由组件接管 */
    searchInputProps?: Omit<RxInputProps, 'value' | 'onChange' | 'placeholder' | 'ref'>;
    /** 透传 MsScrollList props（children 由组件接管，className 与内部合并） */
    scrollListProps?: Omit<MsScrollListProps, 'children'>;
    /** 透传 RxPopover.Trigger props */
    triggerProps?: RxPopoverTriggerProps;
    /**
     * 透传 RxPopover.Content props；className 与内部样式合并。
     * 当外层弹框抬高 z-index 时，可在此同步覆盖 `style.zIndex` 让下拉浮层盖在弹框之上。
     */
    contentProps?: RxPopoverContentProps;
}
