import { default as React } from 'react';
import { MsAccountSelectProps } from './MsAccountSelect.types';
/**
 * MsAccountSelect (妙思扣费账户选择器)
 *
 * 基于 RxPopover 封装，支持搜索、滚动列表、hover 操作按钮等业务能力，
 * 通过 `MsAccountSelectItem` 组合选项。
 *
 * 键盘：↑/↓ 切换焦点（在搜索框与可选项之间移动）、Home/End 跳首尾、Enter 选中、Esc 关闭。
 * 通过原生 DOM 焦点驱动，不维护额外高亮 state。
 */
export declare const MsAccountSelect: React.FC<MsAccountSelectProps>;
