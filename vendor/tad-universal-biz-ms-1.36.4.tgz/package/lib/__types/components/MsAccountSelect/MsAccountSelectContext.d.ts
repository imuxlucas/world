import { ReactNode } from 'react';
/** @internal */
export declare const MSS_ITEM_DISPLAY_NAME = "MsAccountSelectItem";
/** @internal */
export interface MsAccountSelectRegisteredItem {
    value: string;
    label: ReactNode;
}
/** MsAccountSelect ↔ MsAccountSelectItem 通信通道 @internal */
export interface MsAccountSelectContextValue {
    /** 当前选中值 */
    selectedValue: string | undefined;
    /** 选中并关闭浮层 */
    onSelect: (value: string, label?: ReactNode) => void;
    /** 注册当前挂载的 Item，用于 CustomItem 这类组件封装场景回显 trigger */
    registerItem: (item: MsAccountSelectRegisteredItem) => void;
    /** 注销当前卸载的 Item */
    unregisterItem: (value: string) => void;
}
/** @internal */
export declare const MsAccountSelectContext: import('react').Context<MsAccountSelectContextValue | null>;
