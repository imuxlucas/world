import { default as React } from 'react';
import { MsSideNavItemProps } from './MsSideNav.types';
/**
 * MsSideNav.Item - 侧导航项子组件
 */
export declare const MsSideNavItem: React.FC<MsSideNavItemProps>;
/**
 * MsSideNav.Divider - 侧导航分割线子组件
 */
export declare const MsSideNavDivider: React.FC<{
    className?: string;
    media?: 'desktop' | 'mobile';
}>;
