import { default as React } from 'react';
import { MsSideNavProps } from './MsSideNav.types';
import { MsSideNavItem, MsSideNavDivider } from './MsSideNavItem';
import { MsSideNavGroup } from './MsSideNavGroup';
/**
 * MsSideNav (妙思侧导航栏)
 *
 * 通用妙思侧导航栏，支持桌面 / 移动端两种展示方式
 *
 * 文档: https://tad-universal.woa.com/biz-ms/?path=/docs/组件-MsSideNav-妙思侧导航栏--文档
 */
export declare const MsSideNav: React.FC<MsSideNavProps> & {
    Item: typeof MsSideNavItem;
    Divider: typeof MsSideNavDivider;
    Group: typeof MsSideNavGroup;
};
