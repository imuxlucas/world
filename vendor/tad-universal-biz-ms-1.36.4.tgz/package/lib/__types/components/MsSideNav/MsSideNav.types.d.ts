import { default as React } from 'react';
import { MxIconsName } from '@tencent/tad-universal-biz-mx';
import { MsMedia } from '../hooks';
/**
 * @deprecated 使用 MsMedia 替代
 */
export type MsSideNavMedia = MsMedia;
/**
 * 导航项数据
 */
export interface MsSideNavItemData {
    /**
     * 唯一标识
     */
    id?: string;
    /**
     * 类型
     */
    type: 'item';
    /**
     * 图标名称（MxIcon 的 name）
     */
    iconName?: MxIconsName;
    /**
     * 激活态图标名称，不传则沿用 iconName
     */
    iconActiveName?: MxIconsName;
    /**
     * 自定义图标节点
     */
    icon?: React.ReactNode;
    /**
     * 导航项文字
     */
    title?: React.ReactNode;
    /**
     * 图标右上角标签，如 "Beta"
     */
    tag?: React.ReactNode;
    /**
     * 标签样式变体
     * - `default`：白底边框标签（默认）
     * - `emphasis`：使用 MsEmphasisTag 渐变标签渲染
     * @default 'default'
     */
    tagVariant?: 'default' | 'emphasis';
    /**
     * 点击回调
     */
    onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}
/**
 * 分割线数据
 */
export interface MsSideNavDividerData {
    /**
     * 唯一标识
     */
    id?: string;
    /**
     * 类型
     */
    type: 'divider';
}
/**
 * 导航数据项联合类型
 */
export type MsSideNavDataItem = MsSideNavItemData | MsSideNavDividerData;
/**
 * 渲染函数参数
 */
export interface MsSideNavRenderProps {
    /**
     * 当前媒体状态
     */
    media: MsSideNavMedia;
}
/**
 * 组件 MsSideNav (妙思侧导航栏) 的配置项
 */
export interface MsSideNavProps extends React.HTMLAttributes<HTMLElement> {
    /**
     * 强制指定媒体模式
     *
     * 不传则根据窗口宽度自动检测
     */
    media?: MsSideNavMedia;
    /**
     * 导航数据配置
     *
     * 通过 data 配置导航项（优先于 children）
     */
    data?: MsSideNavDataItem[];
    /**
     * 当前激活的导航项 id
     */
    activeId?: string;
    /**
     * 导航项点击回调
     */
    onItemClick?: (item: MsSideNavDataItem, e: React.MouseEvent<HTMLButtonElement>) => void;
    /**
     * 移动端 Drawer 是否展开
     */
    open?: boolean;
    /**
     * 移动端 Drawer 关闭回调
     */
    onClose?: () => void;
    /**
     * 移动端 Drawer 的 Portal 挂载容器
     *
     * 支持传入 CSS 选择器字符串或 DOM 元素，默认为 document.body
     */
    mobileDrawerContainer?: string | Element;
    /**
     * 底部额外内容区（移动端承载顶栏右侧功能）
     *
     * 支持 React 节点或 render props
     */
    endContent?: React.ReactNode | ((props: MsSideNavRenderProps) => React.ReactNode);
}
/**
 * MsSideNav.Group 的配置项
 */
export interface MsSideNavGroupProps extends React.HTMLAttributes<HTMLDivElement> {
    /**
     * 当前媒体状态（由父组件注入）
     *
     * 桌面端渲染 group 容器，移动端不渲染容器、直接平铺子项
     */
    media?: MsMedia;
}
/**
 * MsSideNav.Item 的配置项
 */
export interface MsSideNavItemProps extends Omit<React.HTMLAttributes<HTMLButtonElement>, 'title'> {
    /**
     * 导航项文字
     */
    title?: React.ReactNode;
    /**
     * 图标名称（MxIcon 的 name）
     */
    iconName?: MxIconsName;
    /**
     * 激活态图标名称，不传则沿用 iconName
     */
    iconActiveName?: MxIconsName;
    /**
     * 自定义图标节点
     */
    icon?: React.ReactNode;
    /**
     * 是否选中
     */
    active?: boolean;
    /**
     * 图标右上角标签，如 "Beta"
     */
    tag?: React.ReactNode;
    /**
     * 标签样式变体
     * - `default`：白底边框标签（默认）
     * - `emphasis`：使用 MsEmphasisTag 渐变标签渲染
     * @default 'default'
     */
    tagVariant?: 'default' | 'emphasis';
    /**
     * 当前媒体状态（由父组件注入）
     */
    media?: MsSideNavMedia;
    /**
     * 点击事件
     */
    onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
}
