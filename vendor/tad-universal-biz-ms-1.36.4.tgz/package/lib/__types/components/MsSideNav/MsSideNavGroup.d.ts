import { default as React } from 'react';
import { MsSideNavGroupProps } from './MsSideNav.types';
/**
 * MsSideNav.Group - 侧导航分组子组件
 *
 * 桌面端渲染分组容器，移动端不渲染容器、直接平铺子项
 */
export declare const MsSideNavGroup: React.FC<MsSideNavGroupProps>;
