import { default as React } from 'react';
import { MsMedia } from '../hooks';
/**
 * @deprecated 使用 MsMedia 替代
 */
export type MsTopNavMedia = MsMedia;
/**
 * 右侧内容区渲染函数参数
 */
export interface MsTopNavRenderProps {
    /**
     * 当前媒体状态
     */
    media: MsMedia;
}
/**
 * 组件 MsTopNav (妙思顶部导航栏) 的配置项
 */
export interface MsTopNavProps extends React.HTMLAttributes<HTMLElement> {
    /**
     * 强制指定媒体模式
     *
     * 不传则根据窗口宽度自动检测
     */
    media?: MsMedia;
    /**
     * 左侧 Logo
     *
     * 支持传入图片 URL 字符串或自定义 React 节点
     */
    logo?: string | React.ReactNode;
    /**
     * Logo 的替代文本（当 logo 为 URL 时生效）
     */
    logoAlt?: string;
    /**
     * 点击 Logo 时的回调
     */
    onLogoClick?: () => void;
    /**
     * Logo 右侧内容区
     *
     * 支持传入 React 节点或 render props 函数
     * render props 函数会接收 { media } 参数，用于根据当前视口状态渲染不同内容
     */
    logoAppendContent?: React.ReactNode | ((props: MsTopNavRenderProps) => React.ReactNode);
    /**
     * 最右侧内容区
     *
     * 支持传入 React 节点或 render props 函数
     * render props 函数会接收 { media } 参数，用于根据当前视口状态渲染不同内容
     */
    rightContent?: React.ReactNode | ((props: MsTopNavRenderProps) => React.ReactNode);
}
