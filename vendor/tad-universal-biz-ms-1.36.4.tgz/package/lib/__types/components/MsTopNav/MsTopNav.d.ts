import { default as React } from 'react';
import { MsTopNavProps } from './MsTopNav.types';
/**
 * MsTopNav (妙思顶部导航栏)
 *
 * 通用妙思顶部导航栏实现，支持桌面 / 移动端两种展示方式
 *
 * 文档: https://tad-universal.woa.com/biz-ms/?path=/docs/组件-MsTopNav-妙思顶部导航栏--文档
 */
export declare const MsTopNav: React.FC<MsTopNavProps>;
