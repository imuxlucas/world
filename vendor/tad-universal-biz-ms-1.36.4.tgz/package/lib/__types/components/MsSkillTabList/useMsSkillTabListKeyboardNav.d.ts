import { default as React } from 'react';
import { MsSkillTabListDataGroup, MsSkillTabListItemData, MsSkillTabListNavDirection, MsSkillTabListStatus } from './MsSkillTabList.types';
export interface UseMsSkillTabListKeyboardNavParams {
    enabled: boolean;
    autoHighlightFirst: boolean;
    data?: MsSkillTabListDataGroup[];
    visibleItems: MsSkillTabListItemData[];
    currentTabKey?: string;
    status: MsSkillTabListStatus;
    rootRef: React.RefObject<HTMLDivElement | null>;
    idPrefix: string;
    highlightedKey?: string;
    onHighlightChange?: (key: string | undefined) => void;
    onTabChange?: (key: string) => void;
    onItemActivate?: (item: MsSkillTabListItemData, e?: React.KeyboardEvent) => void;
    onItemClick?: (item: MsSkillTabListItemData, e: React.MouseEvent<HTMLButtonElement>) => void;
}
export interface UseMsSkillTabListKeyboardNavResult {
    /** 当前生效的高亮 key（受控 / 非受控合并后） */
    highlightKey: string | undefined;
    /** 拼接列表项 id（用于 aria） */
    buildItemId: (paneKey: string | undefined, key: string) => string;
    /** 激活 pane 的 aria-activedescendant 目标 id */
    activeDescendantId: string | undefined;
    /** 鼠标 hover 同步高亮（与键盘共用单一游标） */
    setHoverHighlight: (key: string) => void;
    /** 鼠标移出列表：清除高亮，回到无高亮态 */
    clearHover: () => void;
    /** 面板自身获得焦点时（场景 B）的 ↑/↓ / 回车处理 */
    handleKeyDown: (e: React.KeyboardEvent<HTMLDivElement>) => void;
    /** 高亮第一个可用项（用于从 tabs 头部按 ↓ 进入列表） */
    highlightFirst: () => void;
    moveHighlight: (dir: MsSkillTabListNavDirection) => void;
    activateHighlighted: (e?: React.KeyboardEvent) => void;
    getHighlightedItem: () => MsSkillTabListItemData | undefined;
}
/**
 * MsSkillTabList 键盘导航（行优先线性上 / 下浏览）。
 *
 * 把高亮态管理、↑/↓ 线性移动、到首 / 末项越界切 tab、跳过 disabled、
 * 高亮重置（含搜索 / 切 tab）等逻辑收敛在此，
 * 供面板内部使用并通过命令式 ref 暴露给外层（场景 A：焦点在输入框）。
 *
 * 列表导航统一为上 / 下逐个移动；左 / 右不参与列表导航（保留给 tabs）。
 */
export declare function useMsSkillTabListKeyboardNav(params: UseMsSkillTabListKeyboardNavParams): UseMsSkillTabListKeyboardNavResult;
