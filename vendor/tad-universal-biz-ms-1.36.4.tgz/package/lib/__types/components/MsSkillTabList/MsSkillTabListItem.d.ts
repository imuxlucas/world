import { default as React } from 'react';
import { MsSkillTabListItemProps } from './MsSkillTabList.types';
/**
 * MsSkillTabList.Item — 技能标签列表的列表项
 *
 * 可单独使用，也可由父组件 `MsSkillTabList` 自动渲染。
 *
 * 文档: https://tad-universal.woa.com/biz-ms/?path=/docs/组件-MsSkillTabList-技能标签列表--文档
 */
export declare const MsSkillTabListItem: React.ForwardRefExoticComponent<MsSkillTabListItemProps & React.RefAttributes<HTMLButtonElement>>;
