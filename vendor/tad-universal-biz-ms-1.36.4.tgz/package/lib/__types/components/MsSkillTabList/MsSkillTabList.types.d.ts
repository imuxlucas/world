import { default as React } from 'react';
import { MsScrollListProps } from '../MsScrollList/MsScrollList.types';
/**
 * MsSkillTabList 列表项数据
 *
 * 配合 `data[].items` 使用；也可直接使用子组件 `MsSkillTabListItem` 自由组合。
 *
 * 与子组件 `MsSkillTabListItemProps` 共用同一套字段，区别仅在于：
 * - 数据态多一个 `key`（面板用于定位选中项）
 * - 数据态的 `onClick` 是 `(item, e) => void` 签名，便于回调中拿到原始数据
 */
export interface MsSkillTabListItemData {
    /**
     * 列表项唯一标识
     */
    key: string;
    /**
     * 列表项左侧缩略图地址
     *
     * 传入图片 URL，组件内部渲染 `<img>` 并填满媒体区；
     * 不传时不渲染媒体区，列表项仅展示文字。
     */
    imgUrl?: string;
    /**
     * 列表项标题
     */
    title?: React.ReactNode;
    /**
     * 标题旁的标签（如 "常用"）
     */
    tag?: React.ReactNode;
    /**
     * 列表项描述
     */
    description?: React.ReactNode;
    /**
     * 是否禁用
     */
    disabled?: boolean;
    /**
     * 自定义点击回调
     *
     * 不传则触发面板的 `onItemClick`。
     */
    onClick?: (item: MsSkillTabListItemData, e: React.MouseEvent<HTMLButtonElement>) => void;
}
/**
 * MsSkillTabList 分组配置
 *
 * 每个分组对应一个 tab，分组内通过 `items` 直接挂载该 tab 下的列表项。
 * 不同分组的数据相互独立，切换 tab 时列表整体横向平移。
 */
export interface MsSkillTabListDataGroup {
    /**
     * 唯一标识，同时作为 tab 的 key
     */
    key: string;
    /**
     * 标签文字
     */
    label: React.ReactNode;
    /**
     * 该分组下的列表项数据
     */
    items?: MsSkillTabListItemData[];
}
/**
 * MsSkillTabList.Item 子组件的配置项
 *
 * 字段与 `MsSkillTabListItemData` 完全一致（去掉 `key`），
 * 额外提供视觉态 `selected`，
 * 并继承 button 原生属性（其中 `onClick` 使用 button 原生签名）。
 */
export interface MsSkillTabListItemProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'title' | 'prefix' | 'onClick'>, Omit<MsSkillTabListItemData, 'key' | 'onClick'> {
    /**
     * 点击回调（button 原生签名）
     */
    onClick?: React.MouseEventHandler<HTMLButtonElement>;
    /**
     * 是否选中（视觉强调态）
     *
     * 数据驱动模式由面板根据 `selectedKey` 自动注入；
     * `children` 自由组合时由使用方自行控制。
     */
    selected?: boolean;
    /**
     * 是否为键盘高亮项（游标态）
     *
     * 独立于 `selected`（业务已选中）与鼠标 `hover` 的第三种视觉态，
     * 数据驱动模式由面板根据键盘导航自动注入；视觉上需与 `selected` / `hover` 可区分。
     */
    highlighted?: boolean;
}
/**
 * 面板状态（外层完全受控）
 *
 * - `normal` — 默认状态，展示 tabs 与列表
 * - `searching` — 搜索状态，隐藏 tabs，跨分组扁平展示外层已过滤好的全部 items
 * - `empty` — 空态，隐藏 tabs，展示空态占位
 *
 * 是否处于搜索态、是否进入空态，均由外层根据自身搜索关键字 / 数据情况显式传入；
 * 组件内部不做任何推导。
 */
export type MsSkillTabListStatus = 'normal' | 'searching' | 'empty';
/**
 * 方向键导航方向（仅上 / 下）
 *
 * 列表统一为「行优先逐个上 / 下移」的线性浏览：`down` 移到下一个可用项、`up` 移到上一个可用项；
 * 到列表首 / 尾时（`normal` 态）自动越界切换上 / 下一个 tab。
 * 左 / 右不参与列表导航（保留给 tabs：焦点在 tab 上时由 tabs 自身处理左右切换）。
 */
export type MsSkillTabListNavDirection = 'up' | 'down';
/**
 * MsSkillTabList 命令式句柄（通过 `ref` 获取）
 *
 * 适用于「焦点不在面板」的场景（如输入框 slash 浮层）：
 * 由外层输入框的 `onKeyDown` 把上 / 下方向键 / 回车转发进来，组件内部完成
 * 线性移动、跳过 disabled 等逻辑。
 *
 * @example
 * ```tsx
 * const ref = useRef<MsSkillTabListRef>(null);
 * // 输入框 onKeyDown：
 * if (e.key === 'ArrowDown') { e.preventDefault(); ref.current?.moveHighlight('down'); }
 * if (e.key === 'ArrowUp')   { e.preventDefault(); ref.current?.moveHighlight('up'); }
 * if (e.key === 'Enter') ref.current?.activateHighlighted(e);
 * <MsSkillTabList ref={ref} ... />
 * ```
 */
export interface MsSkillTabListRef {
    /**
     * 按上 / 下移动键盘高亮（行优先线性逐个移动）。
     *
     * - `down`：移到下一个可用项；`up`：移到上一个可用项；自动跳过 `disabled` 项。
     * - `normal` 态到列表整体首 / 尾时，自动切换到上 / 下一个 tab 并触发 `onTabChange`，
     *   高亮落到新 tab 的尾 / 首项；已是首 / 末个 tab 时停住。
     * - `searching` 态（无 tabs）首尾停住，不切 tab；空列表为 no-op。
     * - 当前无高亮时：`down` 落到第一个可用项、`up` 落到最后一个可用项。
     */
    moveHighlight: (dir: MsSkillTabListNavDirection) => void;
    /**
     * 激活（回车选中）当前高亮项。
     *
     * 优先触发 `onItemActivate`，否则回退到 item 级 `onClick` / 面板 `onItemClick`。
     * 无高亮项或高亮项 `disabled` 时为 no-op。
     */
    activateHighlighted: (e?: React.KeyboardEvent) => void;
    /**
     * 获取当前键盘高亮项数据（无则返回 `undefined`）。
     */
    getHighlightedItem: () => MsSkillTabListItemData | undefined;
}
/**
 * 组件 MsSkillTabList (技能标签列表) 的配置项
 */
export interface MsSkillTabListProps extends Omit<React.HTMLAttributes<HTMLDivElement>, 'onChange'> {
    /**
     * 面板数据
     *
     * 每项对应一个 tab，分组内的 `items` 即该 tab 下的列表项；
     * 切换 tab 时列表整体横向平移。
     */
    data?: MsSkillTabListDataGroup[];
    /**
     * 当前激活的 tab key
     *
     */
    activeTabKey?: string;
    /**
     * 激活 tab 变化回调
     */
    onTabChange?: (key: string) => void;
    /**
     * 选中的列表项 key（受控）
     */
    selectedKey?: string;
    /**
     * 列表项点击回调
     */
    onItemClick?: (item: MsSkillTabListItemData, e: React.MouseEvent<HTMLButtonElement>) => void;
    /**
     * 面板状态（外层受控）
     *
     * - `normal`（默认）：展示 tabs 与当前分组列表
     * - `searching`：隐藏 tabs，跨分组扁平展示外层已过滤好的全部 items
     * - `empty`：隐藏 tabs 与列表，展示空态占位
     *
     * 状态切换、搜索关键字过滤、关键字高亮均由外层在传入 `data` 前自行实现。
     */
    status?: MsSkillTabListStatus;
    /**
     * 面板高度上限（normal 态）/ 面板高度（searching 态）
     *
     * - normal 态：面板高度由内容最高的 tab 自适应决定（切换 tab 高度不跳动），
     *   该属性作为最大高度限制，超出后由当前列表内部滚动；不传时上限为默认 320px
     * - searching 态：作为面板固定高度；不传时内容自适应，
     *   可通过 `--ms-skill-tab-list-search-max-height` 限制上限
     * - `number`：视为像素值，如 `400` → `400px`
     * - `string`：直接作为 CSS 长度，如 `"400px"` / `"60vh"`
     *
     * empty 态高度固定，不受此属性影响。
     *
     * @default undefined
     */
    height?: number | string;
    /**
     * 空态展示内容
     *
     * 仅当 `status === 'empty'` 时生效；不传则使用组件内置的默认空态。
     */
    emptyContent?: React.ReactNode;
    /**
     * 列表区自定义渲染
     *
     * 接收当前 tab 下的 items（外层传入的原始数据，组件内部不做过滤），
     * 返回 ReactNode 时取代默认列表渲染。
     */
    renderList?: (params: {
        items: MsSkillTabListItemData[];
        activeTabKey?: string;
    }) => React.ReactNode;
    /**
     * 列表区自定义内容（与 `data` 二选一）
     */
    children?: React.ReactNode;
    /**
     * 透传内部 MsScrollList 的 props（如 `endContent` / `hasMore` / `isLoading` /
     * `onLoadMore` / `loadMoreThreshold` / `loadingContent` 等）。
     *
     * `children` 由组件接管；`className` 与内部样式合并。
     * 多 pane（`normal` 态分组）下仅作用于**当前激活**的 pane，避免在隐藏 pane 上误触发触底加载。
     */
    scrollListProps?: Omit<MsScrollListProps, 'children'>;
    /**
     * 是否启用键盘导航（↑/↓ 行优先线性移动高亮 + 回车选中）
     *
     * 启用后：
     * - 面板自身获得焦点时（场景 B），可直接用 ↑/↓ / 回车操作列表；焦点在 tab 上时由 tabs 处理 ←/→ 切换，按 ↓ 回到列表。
     * - 焦点在外部输入框时（场景 A），通过 `ref`（{@link MsSkillTabListRef}）由外层转发 ↑/↓ / 回车驱动。
     *
     * @default true
     */
    enableKeyboardNav?: boolean;
    /**
     * 是否在面板打开 / 切换 tab 时自动高亮第一项
     *
     * - `false`（默认）：初次打开不显示任何高亮，仅当用户开始键盘导航（↑/↓）或鼠标 hover 时才出现高亮游标。
     * - `true`：打开即默认高亮第一个可用项，便于直接回车选中。
     *
     * 注：用户已开始键盘导航（存在高亮）后，搜索 / 切 tab 导致数据变化时仍会把高亮重置到合理位置，不受此开关影响。
     *
     * @default false
     */
    autoHighlightFirst?: boolean;
    /**
     * 当前键盘高亮项 key（受控）
     *
     * 传入则进入受控模式，高亮完全由外层维护；不传时组件内部自行维护高亮（非受控）。
     * 与 `selectedKey`（业务已选中）相互独立。
     */
    highlightedKey?: string;
    /**
     * 键盘高亮项变化回调
     *
     * ↑/↓ 移动、鼠标 hover 同步、鼠标移出列表清除、数据 / tab 变化重置时触发。
     * 受控模式下外层据此更新 `highlightedKey`。
     */
    onHighlightChange?: (key: string | undefined) => void;
    /**
     * 高亮项被激活（回车 / 命令式 `activateHighlighted`）时触发
     *
     * 不传则回退到 item 级 `onClick` / 面板 `onItemClick`。
     */
    onItemActivate?: (item: MsSkillTabListItemData, e?: React.KeyboardEvent) => void;
}
