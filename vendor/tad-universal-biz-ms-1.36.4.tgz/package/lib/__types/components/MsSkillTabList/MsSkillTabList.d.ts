import { default as React } from 'react';
import { MsSkillTabListProps, MsSkillTabListRef } from './MsSkillTabList.types';
import { MsSkillTabListItem } from './MsSkillTabListItem';
/**
 * MsSkillTabList (技能标签列表)
 *
 * 一个集 tabs + 列表 + 空态 于一体的下拉面板。
 * 组件本身只是面板内容，三种唤起方式（hover / 点击 / 输入框/快捷键）由外部控制。
 *
 * 特性：
 * - 数据按 tab 分组（`data[].items`），切换 tab 时列表整体横向平移过渡
 * - `searching` / `empty` 态隐藏 tabs，并在状态间提供淡入淡出过渡
 *
 * 文档: https://tad-universal.woa.com/biz-ms/?path=/docs/组件-MsSkillTabList-技能标签列表--文档
 */
declare const MsSkillTabListBase: React.ForwardRefExoticComponent<MsSkillTabListProps & React.RefAttributes<MsSkillTabListRef>>;
type MsSkillTabListComponent = typeof MsSkillTabListBase & {
    Item: typeof MsSkillTabListItem;
};
export declare const MsSkillTabList: MsSkillTabListComponent;
export {};
