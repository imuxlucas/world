import { default as React } from 'react';
import { RxDialogOverlayProps, RxDialogContentProps, MxButtonProps } from '@tencent/tad-universal-biz-mx';
import { MsBalanceBarItem } from '../MsBalanceBar';
/**
 * MsPaymentConfirmDialog (妙思资金扣费确认弹窗) 的配置项
 */
export interface MsPaymentConfirmDialogProps {
    /** 弹窗是否打开（受控） */
    open?: boolean;
    /** 打开状态变化回调 */
    onOpenChange?: (open: boolean) => void;
    /**
     * 透传 RxDialog.Overlay（遮罩层）props。
     * 业务侧若存在高 z-index 元素导致遮罩盖不住，可在此覆盖 `style.zIndex` / `className`。
     */
    overlayProps?: RxDialogOverlayProps;
    /**
     * 透传 RxDialog.Content（内容区）props。
     * `className` 与内部样式合并；`onOpenAutoFocus` 默认阻止自动聚焦，可覆盖。
     * 覆盖 z-index 时注意：内嵌的账户选择下拉需同步抬高（见 MsAccountSelect `contentProps`）。
     */
    contentProps?: RxDialogContentProps;
    /**
     * 弹窗主体区域（金额区、账户区之后）的自定义内容插槽。
     *
     * 用于外层传入额外的业务内容（如说明文案、扩展信息等），
     * 会渲染在账户区下方、底部操作栏上方，并继承主体区域的间距与内边距。
     */
    children?: React.ReactNode;
    /** 弹窗标题文案，默认 "妙思资金扣费确认" */
    title?: React.ReactNode;
    /** 预计扣费金额值 */
    amount?: React.ReactNode;
    /** 预计扣费标签文案，默认 "预计扣费 (元)" */
    amountLabel?: React.ReactNode;
    /** 提示文案，例如 "扣费顺序：虚拟金 > 赠送金 > 现金" */
    tipText?: React.ReactNode;
    /** 提示文案右侧问号 tooltip 内容（提供时显示 info 图标） */
    tipTooltip?: React.ReactNode;
    /** 副提示文案 */
    subTipText?: React.ReactNode;
    /** 账户区标题文案，默认 "妙思资金账户" */
    accountLabel?: React.ReactNode;
    /** 账户选择器插槽，由外部传入账户选择组件（如 MsAccountSelect） */
    accountContent?: React.ReactNode;
    /**
     * 余额条数据；提供时组件内部通过 `MsBalanceBar` 渲染余额条。
     * - 运算符固定为等式：相邻项之间 `-`，最后一项前 `=`
     * - value 可传字符串或 ReactNode；字符串负数会自动红色高亮
     * - 类型直接复用 `MsBalanceBarItem`，字段结构对外完全兼容
     */
    balanceItems?: MsBalanceBarItem[];
    /**
     * 是否显示「下次不再提示」复选框。
     *
     * - `true`（默认）：底部操作栏左侧渲染复选框和标签，适用于通用扣费确认场景
     * - `false`：隐藏整个复选框区域，底部仅展示取消/确认按钮，适用于
     *   升级确认、一次性确认等场景
     *
     * 隐藏时 `onConfirm` 回调中的 `details.noPromptChecked` 固定为 `false`，
     * `noPromptChecked` / `onNoPromptChange` 可以省略不传。
     *
     * @default true
     */
    showNoPrompt?: boolean;
    /** "下次不再提示" 是否选中（受控） */
    noPromptChecked?: boolean;
    /** "下次不再提示" 变化回调 */
    onNoPromptChange?: (checked: boolean) => void;
    /**
     * 自定义复选框右侧内容节点。
     *
     * 默认渲染文本「下次不再提示」；
     * 传入自定义节点（如协议链接、富文本等）时完全替换默认文本
     *
     * 典型用法：将默认文本替换为协议勾选文案，例如：
     * ```tsx
     * checkboxContentNode={
     *   <>
     *     同意《<a href="...">妙思订阅付费协议</a>》
     *     和《<a href="...">妙思用户服务协议</a>》
     *   </>
     * }
     * ```
     */
    checkboxContentNode?: React.ReactNode;
    /** 取消按钮点击回调 */
    onCancel?: () => void;
    /**
     * 透传给取消按钮的额外 props（用于埋点等场景）。
     *
     * 典型用法是挂载 `data-*` 埋点属性，或补充 `id` / `aria-*` / 其它事件。
     * `onClick` 会与 `onCancel` 合并触发：先执行此处的 `onClick`，
     * 若未调用 `event.preventDefault()`，再执行 `onCancel`。
     *
     * `variant` / `size` / `children` 由组件内部控制，故不可覆盖。
     */
    cancelButtonProps?: Omit<MxButtonProps, 'variant' | 'size' | 'children'>;
    /** 确认按钮点击回调 */
    onConfirm?: (details: {
        noPromptChecked: boolean;
    }) => void;
    /**
     * 透传给确认按钮的额外 props（用于埋点等场景）。
     *
     * 典型用法是挂载 `data-*` 埋点属性，或补充 `id` / `aria-*` / 其它事件。
     * `onClick` 会与 `onConfirm` 合并触发：先执行此处的 `onClick`，
     * 若未调用 `event.preventDefault()`，再执行 `onConfirm`。
     *
     * `variant` / `size` / `children` 由组件内部控制；`disabled` / `loading`
     * 分别由 `confirmDisabled` / `confirmLoading` 驱动，故均不可覆盖。
     *
     * 注意：确认按钮处于禁用态（`confirmDisabled`）时，透传的 `data-*` 等属性
     * 仍会挂载到按钮 DOM 上（便于曝光/无痕埋点），但浏览器对 disabled 元素
     * 不派发指针事件，故 `onClick` 埋点不会触发。
     */
    confirmButtonProps?: Omit<MxButtonProps, 'variant' | 'size' | 'children' | 'disabled' | 'loading'>;
    /** 是否禁用确认按钮 */
    confirmDisabled?: boolean;
    /** 确认按钮禁用时的 tooltip 提示文案 */
    confirmDisabledTooltip?: React.ReactNode;
    /** 确认按钮 loading 状态 */
    confirmLoading?: boolean;
}
