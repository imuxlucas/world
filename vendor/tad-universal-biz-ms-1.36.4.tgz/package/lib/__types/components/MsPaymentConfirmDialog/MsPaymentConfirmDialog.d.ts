import { default as React } from 'react';
import { MsPaymentConfirmDialogProps } from './MsPaymentConfirmDialog.types';
/**
 * MsPaymentConfirmDialog (妙思扣费确认弹窗)
 *
 * 妙思平台资金扣费确认弹窗，包含预计扣费金额展示、扣费账户选择、
 * 余额计算（账户余额 - 本次扣费 = 生成后余额）、"下次不再提示" 复选框、
 * 取消/确认按钮等元素。
 */
export declare const MsPaymentConfirmDialog: React.FC<MsPaymentConfirmDialogProps>;
