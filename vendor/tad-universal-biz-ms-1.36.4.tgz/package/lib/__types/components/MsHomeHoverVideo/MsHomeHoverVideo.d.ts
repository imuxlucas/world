import { MsHomeHoverVideoProps } from './MsHomeHoverVideo.types';
import { default as React } from 'react';
/**
 * MsHomeHoverVideo (首页Hover视频)
 *
 * 首页入口Hover播放/倒播的透明视频
 *
 * 文档: https://tad-universal.woa.com/biz-ms/?path=/docs/组件-MsHomeHoverVideo-首页Hover视频--文档
 */
export declare const MsHomeHoverVideo: React.FC<MsHomeHoverVideoProps>;
