import { default as React, RefObject } from 'react';
import { TransparentVideoProps, TransparentVideoSourceProps } from 'transparent-video-react';
/**
 * 组件 MsHomeHoverVideo (首页Hover视频) 的配置项
 */
export interface MsHomeHoverVideoProps {
    /**
     * 组件类名
     */
    className?: string;
    /**
     * 组件样式
     */
    style?: React.CSSProperties;
    /**
     * 视频帧率 （用于辅助设定倒放的帧频率）
     */
    fps?: number;
    /**
     * 倒放速率
     */
    reverseRate?: number;
    /**
     * 视频源
     */
    sources?: TransparentVideoSourceProps[];
    /**
     * 指定触发倒放的元素
     *
     * 默认为组件根元素
     */
    hoverElementRef?: RefObject<Element>;
    /**
     * 透传给 transparent-video-react 组件的属性
     *
     * 见 https://iyinchao.github.io/transparent-video-react/
     */
    transparentVideoProps?: Omit<TransparentVideoProps, 'children'>;
    /**
     * 是否不使用透明视频，而是使用普通视频(`<video>` 标签)
     *
     * 默认为 false
     */
    noTransparent?: boolean;
    /**
     * webGL错误状态下的回退设置
     *
     * 当不支持透明视频时（如webgl无法创建上下文），图片等作为回退
     */
    glFallback?: string | {
        type: 'image';
        src: string;
        className?: string;
        style?: React.CSSProperties;
    } | React.ReactElement;
}
