// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-ms/lib/MsScrollList' {
  export * from '@tencent/tad-universal-biz-ms/lib/__types/components/MsScrollList';
}
