// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-ms/lib/MsSubjectDropPanel' {
  export * from '@tencent/tad-universal-biz-ms/lib/__types/components/MsSubjectDropPanel';
}
