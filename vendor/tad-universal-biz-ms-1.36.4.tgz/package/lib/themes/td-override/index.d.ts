// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-ms/lib/themes/td-override' {
  export * from '@tencent/tad-universal-biz-ms/lib/__types/themes/td-override';
}
