// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-ms/lib/MsEmphasisTag' {
  export * from '@tencent/tad-universal-biz-ms/lib/__types/components/MsEmphasisTag';
}
