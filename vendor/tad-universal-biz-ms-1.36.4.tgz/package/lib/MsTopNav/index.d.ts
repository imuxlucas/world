// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-ms/lib/MsTopNav' {
  export * from '@tencent/tad-universal-biz-ms/lib/__types/components/MsTopNav';
}
