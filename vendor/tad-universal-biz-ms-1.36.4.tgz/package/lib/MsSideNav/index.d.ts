// Auto generated while build, do not edit
declare module '@tencent/tad-universal-biz-ms/lib/MsSideNav' {
  export * from '@tencent/tad-universal-biz-ms/lib/__types/components/MsSideNav';
}
