import { ButtonProps } from './Button.types';
/**
 * Button (按钮)
 *
 * 基础按钮组件
 */
export declare const Button: React.FC<ButtonProps>;
