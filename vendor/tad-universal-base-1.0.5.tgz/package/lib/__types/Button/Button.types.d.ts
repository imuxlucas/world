import { default as React } from 'react';
/**
 * 组件 Button (按钮) 的配置项
 */
export interface ButtonProps {
    /**
     * 组件类名
     */
    className?: string;
    /**
     * 组件样式
     */
    style?: React.CSSProperties;
    /**
     * 组件内容
     */
    children?: React.ReactNode;
}
