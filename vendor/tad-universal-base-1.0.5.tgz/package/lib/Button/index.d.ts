// Auto generated while build, do not edit
declare module '@tencent/tad-universal-base/lib/Button' {
  export * from '@tencent/tad-universal-base/lib/__types/Button';
}
